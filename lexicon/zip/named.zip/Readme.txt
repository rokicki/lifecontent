This collection is associated with Stephen Silver's Life Lexicon. It contains only named Life objects.
This edition of the collection corresponds to the 25th version of the Lexicon.
----
The composer is Nicolay Beluchenko.
beluch@mail.ru
