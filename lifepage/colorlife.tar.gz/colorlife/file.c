/* All code copyright Paul Callahan 1996  (callahan@inf.ethz.ch) */

#include <stdio.h>
#include <limits.h>
#include "gen.h"
#include <string.h>

extern int spreadColor[];

void readCellsColor(LifeList *cells, char *patname, int color) {
int n,pos,x,y,col;
FILE *patfile;
static char s[1000];
int curx, cury;

   curx=0;
   cury=0;

  if (!(patfile=fopen(patname, "r"))) {
      cells->ncells= 0;
      return;
  }

  n=cells->ncells;

  while (fgets(s, 999, patfile)) {
    if (s[0]=='#') { 
        if (sscanf(s+2, "%d%d", &x, &y)==2) {
           curx=x;
           cury=y;
        }
    } else if (strchr(s,'.') || strchr(s,'*')) {
       for (x=0; s[x]!='\0'; x++) {  
          if (s[x]=='*') {
              pos=pack(curx+x, cury);
              resizeIfNeeded(cells, n+1);

              cells->cellList[n].position=pos;
              cells->cellList[n++].value= color;
          }
       }
       cury++;
    } else {
       col= -1;

       sscanf(s, "%d%d%d",&x, &y, &col);
       pos=pack(x,y);

       resizeIfNeeded(cells, n+1);

       cells->cellList[n].position=pos;
       if (col == -1) 
          cells->cellList[n++].value= color;
       else cells->cellList[n++].value= spreadColor[col];
    }

  }

  cells->ncells=n;

  makeRowMajor(cells);

  fclose(patfile);
  
}
