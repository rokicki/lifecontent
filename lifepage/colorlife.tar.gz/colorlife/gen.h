/* All code copyright Paul Callahan 1996  (callahan@inf.ethz.ch) */

#define INCY (1<<15)
#define INCX (1)
#define CENTER (1<<14)
#define POPHISTORYSIZE 6

#define ERASE  0x0000
#define RED    0x0001
#define GREEN  0x0010
#define BLUE   0x0100
#define YELLOW 0x1000
#define SCROLLREGIONFRACT 6


typedef struct {
   int position;
   unsigned int value;
} Cell;

typedef struct {
    Cell *cellList;
    Cell *scratch1;
    Cell *scratch2;
    Cell *neighborhoods;
    int ncells, maxsize;
  } LifeList;

typedef struct {

   int flipxF, flipyF, transposeF;
   int translateBy;

} Transformation;

typedef struct {

   int period;
   int testedUpTo;
   Transformation T;

} OscillatorDesc;

typedef struct {

   int lx, ux;
   int ly, uy;

} BoundingBox;

typedef struct {

   Cell **cellList;
   int *ncells;

   int ngenerations;
} History;

typedef struct {

   Cell **alignments;
   int *nalignments;

   int firstGen;
   int ngens;
} AlignmentList;

int combineLists(Cell *list1, int n1, Cell *list2, int n2, Cell *list3);

int subtractLists(Cell *list1, int n1, Cell *list2, int n2);

int combineListsMin(Cell *list1, int n1, Cell *list2, int n2, Cell *list3);

void extractCenterCells(Cell *list, int n, Cell *extractFrom);

int nextGen(Cell *counts, int ncounts, Cell *cellList);

void generate(LifeList *cells);

void resizeIfNeeded(LifeList *cells, int n);

int copyList(Cell *fromList, int n, Cell *toList, int translateBy);

int condCopyList(Cell *fromList, int n, Cell *toList, int value);

int sumNeighbors(LifeList *cells);

int minNeighbors(LifeList *cells);

int convolve(Cell *list1, int n1, Cell *list2, int n2,
             Cell *convolution, Cell *scratch1, Cell *scratch2);

void sortRowMajor(Cell *list, int n);

void makeRowMajor(LifeList *cells);

int pack(int x, int y);
int packtrans(int x, int y);

void unpack(int packed, int *x, int *y);

void unpacktrans(int packed, int *x, int *y);

void transpose(Cell *list, int n);

void flipx(Cell *list, int n);

void flipy(Cell *list, int n);

int getValues(Cell *cellList, int n, Cell *valueList);

int pruneList(Cell *keepCells, int n, Cell *inList);

int findComponents(LifeList *cells, LifeList *labeled, int distance);

void dumpCells(Cell *list, int n);

void dumpTransCells(Cell *list, int n);

int firstZero(Cell *list, int n);

int compare(Cell *list1, Cell *list2, int n);

Transformation normalize(LifeList *cells);

void transformBack(Cell *list, Transformation T, int n);

void transform(Cell *list, Transformation T, int n);

OscillatorDesc oscillation(LifeList *cells, LifeList *working, int testUpTo);

BoundingBox makeBoundingBox(Cell *list, int n);

void makeString(Cell *list, int n, char *patstring);

void setValues(Cell *list, int n, int value);

Transformation bestMatch(LifeList *cells1, LifeList *cells2, int *match);

OscillatorDesc partialOscillation(LifeList *cells, LifeList *working, 
                                  int testUpTo, int testPhases);

History makeHistory(LifeList *cells, int ngenerations);

void freeHistory(History hist);

void dumpHistory(History hist);

void getGeneration(LifeList *cells, History hist, int gen);

void initPopHistory();

void longestOscillation(int *period, int *repetition);

void readCellsColor(LifeList *cells, char *patname, int color);

AlignmentList
    firstTouch(LifeList *cells1, LifeList *cells2, int firstGen, int ngens);

void freeAlignmentList(AlignmentList list);

void dumpAlignments(AlignmentList list);

void generateColor(LifeList *cells);

void spreadColors(LifeList *cells);

void initColorTables();

int sumColumnNeighbors(Cell *list, int n, Cell *newlist);

int sumAllNeighbors(Cell *list, int n, Cell *newlist);

int findNeighborhoods(Cell *list, int n, Cell *newlist);
