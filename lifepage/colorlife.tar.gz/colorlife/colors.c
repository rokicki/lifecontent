/* All code copyright Paul Callahan 1996  (callahan@inf.ethz.ch) */

#include <stdio.h>
#include <limits.h>
#include "gen.h"
#include <malloc.h>
#include <assert.h>


int birth[9]=  {0,0,0,1,0,0,0,0,0};  
int survive[9]={0,0,1,1,0,0,0,0,0};  

#define COLOR0 0x0001;
#define COLOR1 0x0010;
#define COLOR2 0x0100;
#define COLOR3 0x1000;

#define SUMF (1<<7)
#define WINF (1<<4)
#define TIEF (1<<3)

int nneighborhoods;

int checkColorTab[0x10000];
int nextColorTab[0x800];

extern int spreadColor[];

int invSpread[6]={ 0, 1, 0, 3, 4, 2 };

#define GETCOLOR(x) invSpread[x%11]

void checkColors(int a, int b, int c, int d,
                 int *sum, int *tie, int *winner) {

   *sum=a+b+c+d;

   if (*sum==3) {
      *tie=0;
           if (a>=2)  *winner= 1;
      else if (b>=2)  *winner= 2;
      else if (c>=2)  *winner= 3;
      else if (d>=2)  *winner= 4;
      else {
         *tie=1;
              if (a==0) *winner= 1;
         else if (b==0) *winner= 2;
         else if (c==0) *winner= 3;
         else if (d==0) *winner= 4;
      }
   } else if (*sum==4) {
     *tie=0;
           if (a>=3)  *winner= 1;
      else if (b>=3)  *winner= 2;
      else if (c>=3)  *winner= 3;
      else if (d>=3)  *winner= 4;
      else {
         *winner=0;
         if (a==1 || b==1 || c==1 || d==1) {
                 if (a==2)  *winner= 1;
            else if (b==2)  *winner= 2;
            else if (c==2)  *winner= 3;
            else if (d==2)  *winner= 4;
            else {
                *tie=1;  
            }
         } else {
            *tie=1;
         } 
      }

   } else {
      *tie=0;
      *winner=0;
   }

}

int nextColor(int sum, int tie, int winner, int oldColor) {
int nextLive;
int newColor;


     if (oldColor== 0) nextLive= birth[sum];
     else nextLive= survive[sum-1];

     if (!nextLive) newColor= 0;
     else {
        if (!tie) newColor= winner;
        else {           
           if (oldColor!=0) newColor= oldColor;
           else newColor=winner;
        } 
     }

     return newColor;
} 

void initColorTables() {

int tsum;
int sum, tie, winner;
int a,b,c,d;
int oldColor, newColor;
int pck1, pck2;

     for (tsum=0; tsum<=9; tsum++)
        for (a=0; a<=tsum; a++) 
           for (b=0; b<=tsum-a; b++) 
              for (c=0; c<=tsum-a-b; c++) { 
                     d=tsum-a-b-c;
                     for (oldColor=0; oldColor<=4; oldColor++) {
                        sum=tie=winner=9;
                        checkColors(a,b,c,d, &sum, &tie, &winner);
                        newColor=nextColor(sum, tie, winner, oldColor);

                        pck1= 
                          a*spreadColor[1] +
                          b*spreadColor[2] +
                          c*spreadColor[3] +
                          d*spreadColor[4];

                        pck2=
                          sum*SUMF + winner*WINF + tie*TIEF;  

                        checkColorTab[pck1]= pck2;
                        nextColorTab[pck2+oldColor]= spreadColor[newColor];

                     }
                  }
     

}

void oscCheck(int n);

void spreadColors(LifeList *cells) {
 int i;

    for (i=0; i<cells->ncells; i++) {

        cells->cellList[i].value=
           spreadColor[cells->cellList[i].value];

    }
}

void checkColorCells(Cell *list, int n) {
   int i;

     for (i=0; i<n; i++) {

         list[i].value= checkColorTab[list[i].value];

     }

 }

void handleCenterColor(Cell *list, int n, Cell *addTo) {

  int i,j;

  i=0; j=0;

  while (i<n) {
    if ( list[i].position == addTo[j].position ) {
      addTo[j].value+= GETCOLOR(list[i].value);
      i++;
      j++;
    } else {
      j++;
    }
  }

}

int nextGenColor(Cell *entries, int nentries, Cell *cellList) {

   int i, ncells;

   ncells=0;

   for (i=0; i<nentries; i++) {
     int nextValue= nextColorTab[entries[i].value];

     if (nextValue) {
       cellList[ncells].position= entries[i].position;
       cellList[ncells++].value= nextValue;
     }
   }

   return ncells;
 }



void generateColor(LifeList *cells) {

  int i,n;

  if (cells->ncells==0) return;

  n=sumNeighbors(cells);

  checkColorCells(cells->neighborhoods, n);

  handleCenterColor(cells->cellList, cells->ncells, cells->neighborhoods);

  cells->ncells= nextGenColor(cells->neighborhoods, n, cells->cellList);

  nneighborhoods= n;
  oscCheck(cells->ncells);
}





void verifyTables() {

int tsum;
int sum, tie, winner;
int a,b,c,d;
int oldColor, newColor, tnewColor;
int pck1, pck2;

     initColorTables();

     for (tsum=0; tsum<=9; tsum++)
        for (a=0; a<=tsum; a++) 
           for (b=0; b<=tsum-a; b++) 
              for (c=0; c<=tsum-a-b; c++) { 
                     d=tsum-a-b-c;
                     for (oldColor=0; oldColor<=4; oldColor++) {
                        sum=tie=winner=9;
                        checkColors(a,b,c,d, &sum, &tie, &winner);
                        newColor=nextColor(sum, tie, winner, oldColor);

                        pck1= 
                          a*spreadColor[1] +
                          b*spreadColor[2] +
                          c*spreadColor[3] +
                          d*spreadColor[4];

                        pck2=
                          sum*SUMF + winner*WINF + tie*TIEF + oldColor;  

                        tnewColor=nextColorTab[checkColorTab[pck1]+
                                         GETCOLOR(spreadColor[oldColor]) ];

                        printf("%4x %d : %4x : %d %4x\n", 
                                 pck1, oldColor, pck2, newColor, tnewColor);
                     }
                  }
     

}



