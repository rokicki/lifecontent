/* Color life for X Motif version 0.0 */
/* Code copyright Paul Callahan, 1996 (unless otherwise noted) */
/* Changed some values to short 20-Dec-97 to get XtGetValues
   to work correctly on most systems.  Please contact me
   callahan@cs.jhu.edu with any bug reports. */

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Xm/DrawingA.h>
#include <Xm/PushB.h>
#include <Xm/FileSB.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include "gen.h"

extern int nneighborhoods;
extern int nextColorTab[];
extern int spreadColor[];

/* This function was found at
    http://ugweb.cs.ualberta.ca/~c311/Notes/colour.html */

int colourindexname(w, name)
Widget w;
char *name; {
     Display *display;
     int  screen;
     Colormap cmap;
     XColor    color, exact;

     display = XtDisplay(w);
     screen = DefaultScreen(display);
     cmap = DefaultColormap(display, screen);


     if(XAllocNamedColor(display, cmap, name,  &color, &exact))
	  return(color.pixel);
     else {
	  printf("Warning: can't allocate requested colour\n");
	  return(BlackPixel(display, screen));
     }
}

/***************************************************************
Some code here is a modified version of code from
"Motif Programming, The Essentials...and More"
by Marshall Brain.
Published by Digital Press, ISBN 1-55558-089-0.
To order the book, call 1-800-DIGITAL and ask for EY-J816E-DP.

Copyright 1992, by Digital Equipment Corp.
***************************************************************/

/* However, some of the above code seemed to be non-portable and
   only worked on the DEC Alpha I wrote this on initially.
   -- PBC, 20-Dec-97 */

XtAppContext context;
XmStringCharSet char_set=XmSTRING_DEFAULT_CHARSET;

int red, green, blue, yellow;
GC gc, redgc, greengc, bluegc, yellowgc, erasegc;
Widget toplevel;
Widget drawing_area;
Widget genButton;
Widget colorButton;
Widget smallerButton, biggerButton;
Widget randomButton;
Widget loadButton;
Widget clearButton;
Widget form;
Widget dialog;

Arg al[10];
int ac;

#define OK 1
#define CANCEL 2

int displayColorTable[5];
char displayColorName[5][7]={"erase", "red", "green", "blue", "yellow"};

LifeList cells;
int userCells;
int generating=0;
int currentColorIndex;
int xc, yc;
int magnification=4;

void setup_gc()
/* set up the graphics context. */
{
    int foreground,background;
    XGCValues vals;

    /* get the current fg and bg colors. */
    ac=0;
    XtSetArg(al[ac],XmNforeground,&foreground); ac++;
    XtSetArg(al[ac],XmNbackground,&background); ac++;
    XtGetValues(drawing_area,al,ac);

    /* create the gc. */
    vals.foreground = foreground;
    vals.background = background;
    gc=XtGetGC(drawing_area,GCForeground | GCBackground, &vals);

    red= colourindexname(drawing_area, "red");
    green= colourindexname(drawing_area, "green");
    blue= colourindexname(drawing_area, "blue");
    yellow= colourindexname(drawing_area, "yellow");

    vals.foreground = red;
    redgc=XtGetGC(drawing_area,GCForeground | GCBackground, &vals);
    displayColorTable[1]= red;

    vals.foreground = green;
    greengc=XtGetGC(drawing_area,GCForeground | GCBackground, &vals);
    displayColorTable[2]= green;

    vals.foreground = blue;
    bluegc=XtGetGC(drawing_area,GCForeground | GCBackground, &vals);
    displayColorTable[3]= blue;

    vals.foreground = yellow;
    yellowgc=XtGetGC(drawing_area,GCForeground | GCBackground, &vals);
    displayColorTable[4]= yellow;

    vals.foreground = background;
    erasegc=XtGetGC(drawing_area,GCForeground | GCBackground, &vals);
    displayColorTable[0]= background;

}

void repaintCells();
void drawCells();

void setWindowCenter() {
int oxc=xc, oyc=yc;
short gxc, gyc;

    ac=0;
    XtSetArg(al[ac],XmNheight, &gyc); ac++;
    XtSetArg(al[ac],XmNwidth, &gxc); ac++;
    XtGetValues(drawing_area,al,ac);

    xc= (int) gxc;
    yc= (int) gyc;

    xc=xc/2;
    yc=yc/2;

    if (oxc!=xc || oyc!=yc) {
        repaintCells();
    } 

}


void drawCell(int position, int value) {
GC *thisgc;
int x,y;

      switch(value) {
      case ERASE:   thisgc= &erasegc; break;
      case RED:     thisgc= &redgc; break;
      case GREEN:   thisgc= &greengc; break;
      case BLUE:    thisgc= &bluegc; break;
      case YELLOW:  thisgc= &yellowgc;
      }

      unpack(position, &x, &y); 

      XFillRectangle(XtDisplay(drawing_area), XtWindow(drawing_area),
		     *thisgc, x*magnification +xc, y*magnification +yc, 
                                magnification, magnification); 
    
}

void repaintCells() {

   nneighborhoods= -1;
   drawCells();

}

void drawCells() {
  int i;
 
  if (nneighborhoods== -1) {

    XFillRectangle(XtDisplay(drawing_area), XtWindow(drawing_area),
                   erasegc, 0, 0, xc*2+1, yc*2+1);

    for (i=0; i<cells.ncells; i++)  {
          drawCell(cells.cellList[i].position, cells.cellList[i].value);
    }
  }
  else {

    for (i=0; i<nneighborhoods; i++) {
      int nval, nextColor;

      nval=cells.neighborhoods[i].value;
      nextColor=nextColorTab[nval];
     
      if ( nextColor != spreadColor[nval&7] ) {
	drawCell(cells.neighborhoods[i].position, nextColor);
      }
        
    }

  }

  XDrawRectangle(XtDisplay(drawing_area), XtWindow(drawing_area),
                 gc, xc/SCROLLREGIONFRACT, yc/SCROLLREGIONFRACT,
                     xc*(SCROLLREGIONFRACT*2-2)/SCROLLREGIONFRACT-1, 
                     yc*(SCROLLREGIONFRACT*2-2)/SCROLLREGIONFRACT-1);

}


void dialogCB(w,client_data,call_data)
    Widget w;
    int client_data;
    XmSelectionBoxCallbackStruct *call_data;
/* callback function for the dialog box */
{

char *fileName;
int lastn;

    switch (client_data)
    {
        case OK:
            XmStringGetLtoR(call_data->value,char_set,&fileName);
            readCellsColor(&cells, fileName, spreadColor[currentColorIndex]);
            XtFree(fileName);
            repaintCells();
            break;
        case CANCEL:
            break;
    }
    XtUnmanageChild(w);
}

void genOff();

void loadCB(w, client_data, call_data)
    Widget w;
    XtPointer client_data;
    XmPushButtonCallbackStruct *call_data;
{
   genOff();
   XtManageChild(dialog);
}

void exposureCB(w,client_data,call_data)
    Widget w;
    XtPointer client_data; 
    XtPointer call_data;
/* called whenever drawing area is exposed. */
{
    repaintCells();
}

void genOn() {

      ac=0;
      XtSetArg(al[ac], XmNlabelString,
               XmStringCreate("Stop", char_set)); ac++; 
      generating=1;
      XtSetValues(genButton, al, ac);

}

void genOff() {

      ac=0;
      XtSetArg(al[ac], XmNlabelString,
               XmStringCreate("Start", char_set)); ac++; 
      generating=0;
      XtSetValues(genButton, al, ac);

}

void toggleCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmAnyCallbackStruct *call_data;
{

    if (generating) {
       genOff();
    } else {
       genOn();
    }
   
}

void smallerCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmAnyCallbackStruct *call_data;
{
    if (magnification > 1) magnification--;
    repaintCells();
}

void biggerCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmAnyCallbackStruct *call_data;
{
    magnification++;
    repaintCells();
}

void randomCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmAnyCallbackStruct *call_data;
{
int i, newColor;
    for (i=0; i<cells.ncells; i++) {
       newColor=random()%4+1;
       cells.cellList[i].value=spreadColor[newColor];
       drawCell(cells.cellList[i].position,
                cells.cellList[i].value);
    }
}

void setLabelColor() {

    ac=0;
    XtSetArg(al[ac],XmNbackground,displayColorTable[currentColorIndex]); ac++;
    XtSetArg(al[ac], XmNlabelString,
             XmStringCreate(displayColorName[currentColorIndex], char_set)); ac++;
    XtSetValues(colorButton, al, ac);
}


void clearCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmAnyCallbackStruct *call_data;
{
    cells.ncells=0;
    repaintCells();
}

void colorCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmAnyCallbackStruct *call_data;
{
    currentColorIndex=(currentColorIndex+1)%5;
    setLabelColor();
}


void cellClicked(w,client_data,event)
    Widget w;
    XtPointer client_data;
    XEvent *event;
/* handles cell clicked in drawing area */
{
int i,x,y;
int addCell;
int transF;

    x=event->xbutton.x;
    y=event->xbutton.y;

    transF=0;

    if (event->type==ButtonPress) {
       if (x< xc/SCROLLREGIONFRACT) {
          copyList(cells.cellList, cells.ncells, 
                   cells.cellList, 
                   packtrans((xc/SCROLLREGIONFRACT-x)/magnification+3, 0));
          transF=1;
       } else if (x> (2*SCROLLREGIONFRACT-1)*xc/SCROLLREGIONFRACT) {
          copyList(cells.cellList, cells.ncells, 
                   cells.cellList, 
packtrans(((2*SCROLLREGIONFRACT-1)*xc/SCROLLREGIONFRACT-x)/magnification-3, 0));
          transF=1;
       }
    
       if (y< yc/SCROLLREGIONFRACT) {
          copyList(cells.cellList, cells.ncells, 
                   cells.cellList, 
                   packtrans(0,(yc/SCROLLREGIONFRACT-y)/magnification+3));
          transF=1;
       } else if (y> (2*SCROLLREGIONFRACT-1)*yc/SCROLLREGIONFRACT) {
          copyList(cells.cellList, cells.ncells, 
                   cells.cellList, 
packtrans(0,((2*SCROLLREGIONFRACT-1)*yc/SCROLLREGIONFRACT-y)/magnification-3));
          transF=1;
       }
    }

    if (transF) repaintCells();
    else if (x>=xc/SCROLLREGIONFRACT && y>=yc/SCROLLREGIONFRACT &&
             x<=(2*SCROLLREGIONFRACT-1)*xc/SCROLLREGIONFRACT &&
             y<=(2*SCROLLREGIONFRACT-1)*yc/SCROLLREGIONFRACT) {

      if (generating) genOff();

      resizeIfNeeded(&cells, cells.ncells+1);

      cells.cellList[cells.ncells].position=
            pack((x-xc-(x<xc)*(magnification-1))/magnification, 
                 (y-yc-(y<yc)*(magnification-1))/magnification);
      cells.cellList[cells.ncells].value= spreadColor[currentColorIndex];
      drawCell(cells.cellList[cells.ncells].position,
               cells.cellList[cells.ncells].value);
      for (i=0; i<cells.ncells; i++) {
          if (cells.cellList[i].position == 
              cells.cellList[cells.ncells].position) {
             cells.cellList[i].value=cells.cellList[cells.ncells].value;
             break;
          }
      }
      if (i==cells.ncells && currentColorIndex!=0) {
         cells.ncells++;
         userCells++;
      }

    }
}

void main(int argc, char *argv[])
{

  int i,n=0;
  int seed,size;
  int x,y;
  int pos;
  History hist;
  int period, repetitions;
  int col=1;
  BoundingBox bb;


  /* create the toplevel shell */
  toplevel = XtAppInitialize(&context,"",NULL,0,&argc,argv,
			     NULL,NULL,0);

  /* set window size. */
  ac=0;
  XtSetArg(al[ac],XmNheight,600); ac++;
  XtSetArg(al[ac],XmNwidth,600); ac++;
  XtSetValues(toplevel,al,ac);

  /* create a form widget */
  ac=0;
  form=XmCreateForm(toplevel,"form",al,ac);
  XtManageChild(form);

  /* create start/stop button */
  ac=0;
  XtSetArg(al[ac], XmNlabelString,
	   XmStringCreate("Start", char_set)); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 4); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 17); ac++;
  genButton=XmCreatePushButton(form, "genbutton", al, ac);
  XtManageChild(genButton);
  XtAddCallback(genButton,XmNactivateCallback,toggleCB,NULL);

  /* create clear button */
  ac=0;
  XtSetArg(al[ac], XmNlabelString,
	   XmStringCreate("Clear", char_set)); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 17); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 30); ac++;
  clearButton=XmCreatePushButton(form, "clearbutton", al, ac);
  XtManageChild(clearButton);
  XtAddCallback(clearButton,XmNactivateCallback,clearCB,NULL);

  /* create color button */
  ac=0;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 30); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 43); ac++;
  colorButton=XmCreatePushButton(form, "colorbutton", al, ac);
  XtAddCallback(colorButton,XmNactivateCallback,colorCB,NULL);
  XtManageChild(colorButton);

  /* create zoom buttons */
  ac=0;
  XtSetArg(al[ac], XmNlabelString,
	   XmStringCreate("bigger", char_set)); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 43); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 56); ac++;
  biggerButton=XmCreatePushButton(form, "biggerbutton", al, ac);
  XtAddCallback(biggerButton,XmNactivateCallback,biggerCB,NULL);
  XtManageChild(biggerButton);

  ac=0;
  XtSetArg(al[ac], XmNlabelString,
	   XmStringCreate("smaller", char_set)); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 56); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 69); ac++;
  smallerButton=XmCreatePushButton(form, "smallerbutton", al, ac);
  XtAddCallback(smallerButton,XmNactivateCallback,smallerCB,NULL);
  XtManageChild(smallerButton);

  /* create random color button */   
  ac=0;
  XtSetArg(al[ac], XmNlabelString,
	   XmStringCreate("random", char_set)); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 69); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 82); ac++;
  randomButton=XmCreatePushButton(form, "randombutton", al, ac);
  XtAddCallback(randomButton,XmNactivateCallback,randomCB,NULL);
  XtManageChild(randomButton);

  /* create load button */
  ac=0;
  XtSetArg(al[ac], XmNlabelString,
	   XmStringCreate("load", char_set)); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNleftPosition, 82); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_POSITION); ac++;
  XtSetArg(al[ac], XmNrightPosition, 95); ac++;
  loadButton=XmCreatePushButton(form, "loadbutton", al, ac);
  XtAddCallback(loadButton,XmNactivateCallback,loadCB,NULL);
  XtManageChild(loadButton);

  /* create file dialog box */
  ac = 0;
  XtSetArg(al[ac], XmNpattern, XmStringCreate("*.lif*", char_set)); ac++;
  dialog=XmCreateFileSelectionDialog(toplevel,"dialog",al,ac);
  XtAddCallback(dialog,XmNokCallback,dialogCB,OK);
  XtAddCallback(dialog,XmNcancelCallback,dialogCB,CANCEL);
  XtUnmanageChild(XmSelectionBoxGetChild(dialog,
      XmDIALOG_HELP_BUTTON));


  /* create a drawing area widget. */
  ac=0;
  XtSetArg(al[ac], XmNtopAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNrightAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNleftAttachment, XmATTACH_FORM); ac++;
  XtSetArg(al[ac], XmNbottomWidget, &genButton); ac++;
  XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_WIDGET); ac++;

  drawing_area=XmCreateDrawingArea(form,"drawing_area",al,ac);
  XtManageChild(drawing_area);
  XtAddCallback(drawing_area,XmNexposeCallback,exposureCB,NULL);
  XtAddEventHandler(drawing_area, ButtonPressMask | ButtonMotionMask, FALSE,
		    cellClicked, NULL);

  setup_gc();

  XtRealizeWidget(toplevel);

  currentColorIndex= 1;
  setLabelColor(); 

  setWindowCenter();

  cells.maxsize=0;
  cells.ncells=0;

  initColorTables();

  repaintCells();

  userCells=0;

   while (1) {
    XEvent event;

    while(generating && !XtAppPending(context)) {
      if (userCells>0) makeRowMajor(&cells);

      generateColor(&cells);
     
      drawCells();

      if (cells.ncells==0) genOff();
    }
    setWindowCenter();

    XtAppNextEvent(context, &event);
    XtDispatchEvent(&event); 

  }
       
}


