//////////////////////////////////////////////////////////////////////////
//									//
// Calculator using John Horton Conway's Numbers and Games		//
// Copyright 1988,1989,1993,1994,1996,2011,2013 by Mark D. Niemiec	//
// This source code is provided as-is,					//
//									//
// This program is free software: you can redistribute it and/or modify	//
// it under the terms of the GNU General Public License as published by	//
// the Free Software Foundation, either version 3 of the License, or	//
// (at your option) any later version.					//
//									//
// This program is distributed in the hope that it will be useful,	//
// but WITHOUT ANY WARRANTY; without even the implied warranty of	//
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the	//
// GNU General Public License for more details.				//
//									//
// You should have received a copy of the GNU General Public License	//
// along with this program. If not, see <http://www.gnu.org/licenses/>.	//
//									//
//////////////////////////////////////////////////////////////////////////

#include <stdio.h>		// fclose fflush fopen fprintf getc stderr stdin printf putchar ungetc
#include <stdlib.h>		// exit free malloc
#include <string.h>		// strchr strcmp strcpy strlen



// Configurable parameters

#define	MAXNAME		80	// Maximum identifier length



//////////////////////////////////////////////////////////////////////////
//                                                                      //
//	Syntax description						//
//									//
//////////////////////////////////////////////////////////////////////////



// Syntax:

// statement	=	NL			// Empty line
//		|	expr NL			// Set of numbers/games
//		|	vexpr NL		// Operator

// expr		=	name			// Name assigned to a value
//		|	name asg expr		// Assign a variable
//		|	name asg		// Erase a variable
//		|	'(' ')'			// Empty set
//		|	'(' expr ')'
//		|	'{' '}'			// Empty set
//		|	'{' expr '}'
//		|	'|'			// Ordional zero { | } = 0
//		|	'|' expr		// Negative ordinal { | y }
//		|	unary expr
//		|	expr '|'		// Positive ordinal { x | }
//		|	expr '|' expr		// Arbitrary number { x | y }
//		|	expr binary expr
//		|	expr expr		// Implicit concatenation
//		|	'??' NL			// Display all symbols

// vexpr	=	name			// Name assigned to an operator
//		|	name asg vexpr
//		|	name asg		// Erase an operator variable
//		|	'(' vexpr ')'
//		|	'{' vexpr '}'
//		|	binary
//		|	asg

// asg		=	'='			// Assign variable
//		|	'=:'			// Assign constant

// binary	=	'<'			// Less Than
//		|	'>'			// Greater Than
//		|	'=='			// Equals
//		|	'?'			// Fuzzy
//		|	'!<'			// Not Less Than
//		|	'!>'			// Not Greater Than
//		|	'!='			// Not Equal
//		|	'!?'			// Not Fuzzy
//		|	'<='			// Less or Equal
//		|	'>='			// Greater or Equal
//		|	'<?'			// Less or Fuzzy
//		|	'>?'			// Greater or Fuzzy
//		|	'<>'			// Less or Greater
//		|	'?='			// Equal or Fuzzy
//		|	'::'			// Compare (equal=0, less=-1, greater=1, fuzzy=*)
//		|	','			// Concatenate (explicit)
//		|	'!'			// Tardy Union (Or)
//		|	'!!'			// Urgent Union (Ur)
//		|	'&' 			// Fast Join (And)
//		|	'&&' 			// Slow Join (Also)
//		|	'>>' 			// Maximum (Niemiec)
//		|	'<<' 			// Minimum (Niemiec)
//		| 	'+' 			// Add
//		|	'-' 			// Subtract
//		| 	'.' 			// Multiply
//		|	'..' 			// Norton Multiply
//		|	':' 			// Ordinal Sum

// unary	=	'+' expr		// Self
//		|	'-' expr		// Negate
//		|	'.' expr		// Star
//		|	'>>' expr		// Absolute
//		|	'<<' expr		// Negative absolute
//		|	'<' expr		// Left set
//		|	'>' expr		// Right set
//		|	'&' expr		// Depth (day number)
//		|	'?' expr		// Print relative position

// Everything from ';' to the end of a line is a comment, and is ignored.

// Names are any sequence of any non-blank characters except:
//	!&()+,-:;<=>?[]{|}~
//	([] are currently not used, but are reserved for future use)
//	The special names . and .. are reserved for operators.
// In particular, the following characters ARE frequently used in names:
//	$*./\_ 0..9 A..Z a..z
//	Non-ASCII characters may be used, but due to character set conversion
//	issues, such usage is not portable.
// The following are never used, but are currently permitted:
//	"#%'@`



//////////////////////////////////////////////////////////////////////////
//                                                                      //
//	Type definitions						//
//									//
//////////////////////////////////////////////////////////////////////////



// Basic types

typedef unsigned char	tBool;			// Boolean
enum			{ FALSE, TRUE };



// Structure typedefs

typedef FILE *		tpFILE;
typedef void *		tpVoid;
typedef char *		tString;
typedef tString *	tpString;
typedef char const *	tcString;
typedef struct tMatrix *tpMatrix;
typedef tpMatrix *	tppMatrix;
typedef struct tNumber *tpNumber;
typedef tpNumber *	tppNumber;
typedef struct tSet *	tpSet;
typedef tpSet *		tppSet;
typedef struct tVector *tpVector;
typedef tpVector *	tppVector;



// Typecasts of NULL (and a few pseudo-NULLs)

#define	NULLFILE	(tpFILE (NULL))
#define	NULLvoid	(tpVoid (NULL))
#define	NULLstring	(tString (NULL))
#define	NULLMatrix	(tpMatrix (NULL))
#define	NULLNumber	(tpNumber (NULL))
#define	NULLSet		(tpSet (NULL))
#define	NULLSetP	(tppSet (NULL))
#define	NULLVector	(tpVector (NULL))



// Set structure.
// A set is a list of zero or more numbers

enum tSetFlags {			// Set flags:
	SF_USED		= 0x01,		//   permanent member
	SF_NUMB		= 0x02,		//   this is some number.n_set
	SF_NONE		= 0x00,		//   (none of the above)
};

struct tNumber;

#define	s_link	s_su.su_link
#define	s_name	s_su.su_name

struct tSet {
	union {
		tpSet	su_link;	// forward link in alloc chain, if any
		tcString su_name;	// variable name for input purposes
	} s_su;
	tpSet		s_next;		// forward link in chain, if any
	tpNumber	s_number;	// list element
	tSetFlags	s_flags;	// flags

			tSet (tpNumber number = NULLNumber):
			  s_next (NULLSet), s_number (number), s_flags (SF_NONE)
			  { s_link = NULLSet; }
};

tSet SELFSet;				// 'magic' set containing self (for loopy games)
tSet ERRSet;				// 'magic' Set indicating error



// Number structure
// A number consists of a left-set and right-set.
// For computational convenience, a numbers negative is also remembered, if it exists.
// For display convenience, simple numbers are so indicated.
//
// NOTE: tNumbers with n_day<0 are NOT actual numbers; rather, they are
// 'magic' syntactic entities with lexical values of ~n_day.
// These are used to allow user-assignment of syntactic entities
// (e.g. plus =: +) but are not used in non-syntactic numeric context

enum tNodeType {			// Node type:
	NT_COMBINE,			//   generic combination
	NT_FRACT,			//   generalized fraction (currently unused)
	NT_NIMBER,			//   nimber (currently unused)
	NT_SYNTAX,			//   non-numeric syntactic entity
};

enum tNodeFlags {			// Node flags:
	NF_NONE		= 0x00,		//   nothing (default)
	NF_PERM		= 0x01,		//   permanent member (i.e. variable or constant)
};

typedef	long	tNodeDepth;		// depth of tree node (day-number)
#define	DAY_ON	0x40000000L		// virtually infinite depth

struct tNumber {
	tpNumber	n_link;		// forward link in alloc chain, if any
	tpNumber	n_neg;		// corresponding negative, if any
	tpSet		n_left;		// left set
	tpSet		n_right;	// right set
	tNodeDepth	n_day;		// age of tree (day-number)
	tNodeType	n_type;		// type of number
	tNodeFlags	n_flags;	// flags
	tcString	n_name;		// name for display purposes, if any
	tSet		n_set;		// set containing only this number
	tpVector	n_vec;		// vector of known unary results
	tpMatrix	n_mat;		// matrix of known binary results

			// Construct number from two sets
			tNumber (tpSet left = NULLSet, tpSet right = NULLSet, int day = 0):
			  n_link (NULLNumber), n_neg (NULLNumber), n_left (left), n_right (right),
			  n_day (day), n_type (NT_COMBINE), n_flags (NF_NONE),
			  n_name (NULLstring), n_set (this), n_vec (NULLVector), n_mat (NULLMatrix) { }
			// Construct non-numeric syntactic entity
			tNumber (int i):
			  n_link (NULLNumber), n_neg (NULLNumber), n_left (NULLSet), n_right (NULLSet),
			  n_day (~i), n_type (NT_SYNTAX), n_flags (NF_NONE),
			  n_name (NULLstring), n_set (this), n_vec (NULLVector), n_mat (NULLMatrix) { }
};



// Type of known results
// Unary and binary functions are currently distinct, although they need not be.

enum tVectorType {
	VT_NULL,			// unused

					// Unary results:
//	VT_LEFT,			// Allow left side to pass (currently unused)
//	VT_RIGHT,			// Allow right side to pass (currently unused)
//	VT_STAR,			// Allow either side to pass (currently unused)
//	VT_NEG,				// -  negate (deprecated: now use n_neg instead)
	VT_IMP,				// \+ impartial

	VT_LE,                          // <= less or equal (non-commutative)
	VT_ADD,				// +  add
	VT_SUB,				// -  subtract (non-commutative)
	VT_MUL,				// .  multiply
	VT_NMUL,			// .. Norton multiplication
	VT_ORD,				// :  ordinal sum (non-commutative)
//	VT_UNDO,			// >>> left may undo right move (currently unused)
	VT_MAX,				// >> maximum
	VT_AND,				// &  fast join
	VT_ALSO,			// && slow join
	VT_OR,				// !  tardy union
	VT_UR,				// !! urgent union
	VT_NARROW,			// ~  narrow sum
};



// Matrix of known results
// This consists of zero or more vectors of results with different operands

struct tMatrix {
	tpMatrix	m_fwd;		// forward link
	tpVector	m_vec;		// vector of known results
	tpNumber	m_rte;		// right parameter this refers to
};



// Vector of known results
// This consists of zero or more results with different operands

struct tVector {
	tpVector	v_fwd;		// forward link
	tpNumber	v_num;		// numerical result
					// (if NULL, entry is being built)
	tVectorType	v_op;		// operation this refers to
};



// Lexical tokens returned by lexical evaluator

enum eToken {
	L_NULL,				// unused			00
	L_EOL,				// newline			01
	L_TERM,				// terminal			02
	L_LPAREN,			// (				03
	L_RPAREN,			// )				04
	L_LBRACE,			// {				05
	L_RBRACE,			// }				06
	L_SUMM,				// ??		Summary		07
	L_ASG,				// =		Assign		08
	L_CASG,				// =:		Assign constant	09
	L_BAR,				// | || ||| ...	Combine		10

	L_OR,				// !		Tardy union	11
	L_UR,				// !!		Urgent union	12
	L_AND,				// &		Fast join	13
	L_ALSO,				// &&		Slow join	14
	L_MAX,				// >>		Maximum		15
	L_MIN,				// <<		Minimum		16
	L_ADD,				// +		Add		17
	L_SUB,				// -		Subtract	18
	L_MUL,				// .		Multiply	19
	L_ORD,				// :		Ordinal sum	20
	L_COMMA,			// ,		Concatenate	21
	L_LT,				// <		Less Than	22
	L_LE,				// <=		Less Or Equal	23
	L_LF,				// <?		Less Or Fuzzy	24
	L_GT,				// >		More Than	25
	L_GE,				// >=		More Or Equal	26
	L_GF,				// >?		More Or Fuzzy	27
	L_LG,				// <>		More Or Less	28
	L_EQ,				// ==		Equal		29
	L_NE,				// !=		Not Equal	30
	L_FUZ,				// ?		Fuzzy		31
	L_NF,				// !?		Not Fuzzy	32
	L_EF,				// ?=		Fuzzy Or Equal	33
	L_NL,				// !<		Not Less Than	34
	L_NG,				// !>		Not More Than	35
	L_CMP,				// ::		Compare		36
	L_NMUL,				// ..		Norton Multiply	37

	L_ALL,				// (all tokens are below this)	38
	L_ASSIGNABLE	= L_OR,		// (all tokens this and above are assignable)
};

tcString lexsymbols[L_ALL] = {		// names of all token types
	"", "end of line", "variable", "(", ")", "{", "}", "??", "=", "=:",
	"|", "!", "!!", "&", "&&", ">>", "<<", "+", "-", ".",
	":", ",", "<", "<=", "<?", ">", ">=", ">?", "<>", "==",
	"!=", "?", "!?", "?=", "!<", "!>", "::", ".."
};



// Operator precedence

enum ePrecedence {
	P_LO,				// (x) {x} x=y x:=y		0
	P_CMP,				// x<y x>y x==y x::y etc.	1
	P_BAR = 202,			// x|y (||=P_BAR-1, |||=P_BAR-2 etc.)
	P_CAT,				// x,y 				203
	P_OR,				// x!y x!!y			204
	P_AND,				// x&y x&&y			205
	P_MAX,				// x>>y x<<y			206
	P_ADD,				// x+y x-y x:y 			207
	P_MUL,				// x.y x..y 			208
	P_UNARY,			// +x -x >>x <<x <x >x &x ::x !x 209
	P_VEC,				// x y				210
	P_HI,				// (all priorities are below this) 211
};



//////////////////////////////////////////////////////////////////////////
//									//
//	Memory allocation functions					//
//									//
//////////////////////////////////////////////////////////////////////////



// Memory allocation globals

tpSet	Variables = NULLSet;		// list of defined variables
tpNumber Numbers = NULLNumber;		// list of all known numbers
tpNumber Nfree = NULLNumber;		// list of unused numbers
tpSet	Sets = NULLSet;			// list of all known sets
tpSet	Sfree = NULLSet;		// list of unused sets
long	nnumbers = { 0 };		// number of used number nodes (debug)
long	nsets = { 0 };			// number of used set nodes (debug)
long	nvectors = { 0 };		// number of used vector nodes (debug)
long	nmatrix = { 0 };		// number of used matrix nodes (debug)
long	nchars = { 0 };			// number of chars in names (debug)



// Display memory statistics

void PrintStats ()
{
	printf ("\n%ld numbers, %ld sets, %ld vectors, %ld matrices, %ld chars\n",
	  nnumbers, nsets, nvectors, nmatrix, nchars);
}



// Allocate memory.
// If none is available, all caches are purged.
// If still none are available, abort (if force==TRUE)
// If force==FALSE, return NULL even after successful cache flush;
// (This is necessary in the special case in which allocating a Matrix
//  succeeds, but allocating a sub-Vector purges the cache and destroys
//  the Matrix; linking the new Vector into that would be disastrous.)

tpVoid xalloc (
	int		n,		// number of bytes to allocate
	tBool		force)		// allocate even after garbage-collection
{
	tpVoid		p;		// allocated buffer
	tpNumber	np;		// number being garbage-collected
	tpSet		sp;		// set being garbage-collected
	tpMatrix	m;		// matrix cache element being garbage collected
	tppMatrix	mp;		// pointer to current matrix cache element
	tpVector	v;		// vector cache element being garbage collected
	tppVector	vp;		// pointer to current vector cache element
	int		pass;		// garbage collection pass (0=none)

	for (pass = 0; (p = malloc (n)) == NULLvoid; ++pass) {
		printf ("Garbage collecting: ");
		PrintStats ();

		if (pass > 0) {
			printf ("Not enough memory!\n");
			exit (1);
		}

		while ((np = Nfree) != NULLNumber) {	// free number cache
			Nfree = np->n_link;
			free (np);
		}

		while ((sp = Sfree) != NULLSet) {	// free set cache
			Sfree = sp->s_link;
			free (sp);
		}

		for (np = Numbers; np != NULLNumber; np = np->n_link) {
			for (vp = &np->n_vec; (v=*vp) != NULLVector; ) {
				if (v->v_num == NULLNumber) {	// Busy vector: bypass
					vp = &v->v_fwd;
				} else {		// free vector
					*vp = v->v_fwd;
					free (v);
					--nvectors;
				}
			}

			for (mp = &np->n_mat; (m=*mp) != NULLMatrix; ) {
				for (vp = &m->m_vec; (v=*vp) != NULLVector; ) {
					if (v->v_num == NULLNumber) {	// Busy vector: bypass
						vp = &v->v_fwd;
					} else {		// free vector
						*vp = v->v_fwd;
						free (v);
						--nvectors;
					}
				}

				if (m->m_vec != NULLVector) {	// Busy matrix
					mp = &m->m_fwd;
				} else {			// free matrix
					*mp = m->m_fwd;
					free (m);
					--nmatrix;
				}
			}
		}

		if (!force) {
			return NULL;
		}
	}

	return p;
}



// Make a new number out of two sets.
// This is called directly to create initial constants,
// and subsequently to create numbers that have already been simplified.

tpNumber AllocNum (
	tpSet		l,		// Left set
	tpSet		r,		// Right set
	tNodeDepth	day)		// Day-number
{
	tpNumber	n;		// allocated number

	if ((n = Nfree) != NULLNumber) {
		Nfree = n->n_link;
	} else {
		++nnumbers;
		n = tpNumber (xalloc (sizeof (tNumber), TRUE));
	}

	n->n_neg = NULLNumber;
	n->n_left = (l == &SELFSet) ? &n->n_set : l;
	n->n_right = (r == &SELFSet) ? &n->n_set : r;
	n->n_day = day;
	n->n_type = NT_COMBINE;
	n->n_flags = NF_NONE;
	n->n_name = NULLstring;
	n->n_set.s_number = n;
	n->n_set.s_flags = SF_NUMB;
	n->n_set.s_next = NULLSet;
	n->n_vec = NULLVector;
	n->n_mat = NULLMatrix;
	n->n_link = Numbers;		// Hook this into front of numbers list
	Numbers = n;
	return n;
}



// Allocate a set element, creating a set containing one number
// If name!=NULLstring, this is an allocation for a new variable
// This is never needed when allocating the first item of a set,
// because each number contains within itself a set containing only itself.

tpSet AllocSet (
	tpNumber	n,		// number to create set from
	tcString	name)		// name of of new variable (or NULL)
{
	tpSet		s;		// set being created

	if ((s = Sfree) != NULLSet) {
		Sfree = s->s_link;
	} else {
		++nsets;
		s = tpSet (xalloc (sizeof (tSet), TRUE));
	}

	s->s_next = NULLSet;
	s->s_number = n;
	s->s_flags = SF_NONE;

	if (name == NULLstring) {
		s->s_link = Sets;
		Sets = s;
	} else {
		s->s_name = name;
	}

	return s;
}



// Free a number (not currently used)

#if 0
void FreeNum (
	tpNumber	n)		// number to free
{
	n->n_link = Nfree;
	Nfree = n;
}
#endif



// Free a set element (not currently used)

#if 0
void FreeSet (
	tpSet		s)		// set to free
{
	if (s == &s->s_number->n_set) {	// Don't free internal set!
		return;
	}

	if (s->s_name != NULL) {
		nchars -= strlen (s->s_name) + 1;
		free (s->s_name);
	}

	s->s_link = Sfree;
	Sfree = s;
}
#endif



// Mark entire data structure as temporary (not currently used)

#if 0
void UnUse ()
{
	tpNumber	n;		// number being marked as temporary
	tpSet		s;		// set being marked as temporary

	for (n = Numbers; n != NULLNumber; n = n->n_link) {
		n->n_flags &= ~NF_PERM;
		n->n_set.s_flags &= ~SF_USED;
	}

	for (s = Sets; s != NULLSet; s = s->s_link) {
		s->s_flags &= ~SF_USED;
	}

	for (s = Variables; s != NULLSet; s = s->s_next) {
		s->s_flags &= ~SF_USED;
	}
}
#endif


// Mark a number as being used (not currently used)

#if 0
void UseSet (tpSet s);

void UseNum (
	tpNumber	n)		// number being marked as permanent
{
	if (n != NULLNumber && (n->n_flags&NF_PERM) == 0) {
		n->n_flags |= NF_PERM;
		n->n_set.s_flags |= SF_USED;
		UseSet (n->n_left);
		UseSet (n->n_right);
	}
}
#endif



// Mark a set as being used (not currently used)

#if 0
void UseSet (
	tpSet		s)		// set being marked as permanent
{
	for (; s != NULLSet && (s->s_flags&SF_USED) == 0; s = s->s_next) {
		s->s_flags |= SF_USED;
		UseNum (s->s_number);
	}
}
#endif



// Dispose of all unused numbers and sets (not currently used)
// (For now, this code is disabled, since garbage collection of Matrix and
// Vector elements would be a major headache)

void GarbageCollect ()
{
#if 0
	tpNumber	n;		// number being examined
	tppNumber	np;		// pointer to number being examined
	tpSet		s;		// set being examined
	tppSet		sp;		// pointer to set being examined

	UnUse ();
	UseSet (Variables);

	nnumbers = 0;
	for (np = &Numbers; (n=*np) != NULLNumber; ) {
		if (n->n_flags & NF_PERM) {
			++nnumbers;
			np = &n->n_link;
		} else {
			*np = n->n_link;
			FreeNum (n);
		}
	}

	nsets = 0;
	for (sp = &Sets; (s=*sp) != NULLSet; ) {
		if (s->s_flags & SF_USED) {
			++nsets;
			sp = &s->s_link;
		} else {
			*sp = s->s_link;
			FreeSet (s);
		}
	}
#endif
}



//////////////////////////////////////////////////////////////////////////
//									//
//	Number Engine							//
//									//
//////////////////////////////////////////////////////////////////////////



// Globals used by number engine

tMatrix	DummyMatrix;			// Dummy matrix for MakeNum if we run out of memory
tVector	DummyVector;			// Dummy vector for MakeNum if we run out of memory

tpNumber N_0;				// 0 = {|} = - 0
tpNumber N_1;				// 1 = {0|} = - -1
tpNumber N_n1;				// -1 = {|0} = - 1
tpNumber N_star;			// * = {0|0} = - *
tpNumber N_on;				// on = {on|} = - off
tpNumber N_off;				// off= {|off} = - on
tpNumber N_dud;				// dud = {dud|dud} = - dud



// Create a loopy number (just a stub for now)

tpNumber Loopy ()
{
	printf ("Cannot create non-standard loopy games\n");
	return NULLNumber;
}



// Find the pre-computed value of a unary operation on a number.
// If this has not been computed yet, allocate an empty cell for the result.

tpVector OpVector (
	tpNumber	a,		// right operand of unary operator
	tVectorType	op)		// unary operation being performed
{
	tpVector	v;		// vector cache element being examined
	tppVector	vp;		// pointer to current vector cache element

	for (vp = &a->n_vec; ; vp = &v->v_fwd) {
		if ((v = *vp) == NULLVector) {	// Not found:
			*vp = v = tpVector (xalloc (sizeof (*v), FALSE));
			if (v == NULLVector) {	//   no room: use a temp. slot
				DummyVector.v_num = NULLNumber;
				return &DummyVector;
			}

			++nvectors;		//   allocate a new cache slot
			v->v_fwd = NULLVector;
			v->v_num = NULLNumber;	// Entry is busy until filled
			v->v_op = op;
			break;
		} else if (v->v_op == op) {	// Found: use old cache slot
			break;
		}
	}

	return v;
}



// Find the pre-computed value of a non-commutative binary operation on two numbers.
// If this has not been computed yet, allocate an empty cell for the result.

tpVector OpMatrix (
	tpNumber	a,		// left operand of binary operator
	tpNumber	b,		// right operand of binary operator
	tVectorType	op)		// binary operation being performed
{
	tpMatrix	m;		// matrix cache element being examined
	tppMatrix	mp;		// pointer to current matrix cache element
	tpVector	v;		// vector cache element being examined
	tppVector	vp;		// pointer to current vector cache element

	if (a->n_mat == &DummyMatrix || b->n_mat == &DummyMatrix) {
dummy:		DummyVector.v_num = NULLNumber;
		return &DummyVector;
	}

	for (mp = &a->n_mat; ; mp = &m->m_fwd) {
		if ((m=*mp) == NULLMatrix) {
			*mp = m = tpMatrix (xalloc (sizeof (*m), FALSE));
			if (m == NULLMatrix) {
				goto dummy;
			}
			++nmatrix;
			m->m_fwd = NULLMatrix;
			m->m_vec = NULLVector;
			m->m_rte = b;
			break;
		} else if (m->m_rte == b) {
			break;
		}
	}

	for (vp = &m->m_vec; ; vp = &v->v_fwd) {
		if ((v=*vp) == NULLVector) {
			*vp = v = tpVector (xalloc (sizeof (*v), FALSE));
			if (v == NULLVector) {
				goto dummy;
			}
			++nvectors;
			v->v_fwd = NULLVector;
			v->v_num = NULLNumber;	// Entry is busy until filled in
			v->v_op = op;
			break;
		} else if (v->v_op == op) {
			break;
		}
	}

	return v;
}



// Find the pre-computed value of a commutative binary operation on two numbers.
// If this has not been computed yet, allocate an empty cell for the result.

tpVector OpCommute (
	tpNumber	a,		// left operand of binary operator
	tpNumber	b,		// right operand of binary operator
	tVectorType	op)		// binary operation being performed
{
	if (a <= b) {			// arbitrarily prioritize based on memory position
		return OpMatrix (a, b, op);
	} else {
		return OpMatrix (b, a, op);
	}
}



// Return TRUE, if a <= b (Conway's definition)
//
// AXIOM:	a <= b	<==>  no b<=al and no br<=a
// THEOREM:	a <= a	= 1
// THEOREM:	a <= on	= 1
// THEOREM:	off <= a = 1
// THEOREM:	dud <= a =	a <= dud =	0

tBool NumLE (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	tpSet		s;		// set element being examined
	tpVector	v;		// matrix cachele element

	if (a == b) {			// a <= a = 1
		return TRUE;
	} else if (a == N_off || b == N_on) {	// off <= b = 1; a <= on = 1
		return TRUE;
	} else if (a == N_dud || b == N_dud) {	// dud <= b = 0; a <= dud = 0
		return FALSE;
	}

	v = OpMatrix (a, b, VT_LE);

	if (v->v_num != NULLNumber) {
		return v->v_num != N_0;
	}

	for (s = a->n_left; s != NULLSet; s = s->s_next) {
		if (NumLE (b, s->s_number)) {
			v->v_num = N_0;
			return FALSE;
		}
	}

	for (s = b->n_right; s != NULLSet; s = s->s_next) {
		if (NumLE (s->s_number, a)) {
			v->v_num = N_0;
			return FALSE;
		}
	}

	v->v_num = N_1;
	return TRUE;
}



// Return TRUE, if a <| b (Conway's definition)
//
// AXIOM:	a <| b	<==>  a !>= b
// THEOREM:	a !<| a

tBool NumLF (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && !NumLE (b, a);
}



// Return TRUE, if a < b (Conway's definition)
//
// AXIOM:	a < b	<==>  a <= b  and  a !>= b
// THEOREM:	a !< a

tBool NumLT (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && NumLE (a, b) && !NumLE (b, a);
}



// Return TRUE, if a !< b (Conway's definition)
//
// AXIOM:	a !< b	<==>  a !<= b  or  a >= b
// AXIOM:	a !< a

tBool NumNL (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a == b || !NumLE (a, b) || NumLE (b, a);
}



// Return TRUE, if a >= b (Conway's definition)
//
// AXIOM:	a >= b	<==>  b <= a
// THEOREM:	a >= a

tBool NumGE (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return NumLE (b, a);
}



// Return TRUE, if a |> b (Conway's definition)
//
// AXIOM:	a |> b	<==>  a !<= b
// THEOREM:	a !|> a

tBool NumGF (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && !NumLE (a, b);
}



// Return TRUE, if a > b (Conway's definition)
//
// AXIOM:	a > b	<==>  a >= b  and  a !<= b
// THEOREM:	a !> a

tBool NumGT (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && NumLE (b, a) && !NumLE (a, b);
}



// Return TRUE, if a !> b (Conway's definition)
//
// AXIOM:	a !> b	<==>  a !>= b  or  a <= b
// THEOREM:	a !> a

tBool NumNG (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a == b || !NumLE (b, a) || NumLE (a, b);
}



// Return TRUE, if a <> b (Conway's definition)
//
// AXIOM:	a <> b	<==>  a <= b  xor  a >= b
// THEOREM:	a !<> a

tBool NumLG (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && (NumLE (a, b) ^ NumLE (b, a));
}



// Return TRUE, if a == b (Conway's definition)
//
// AXIOM:	a == b	<==>  a <= b  and  a >= b
// THEOREM:	a == a

tBool NumEQ (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a == b || NumLE (a, b) && NumLE (b, a);
}



// Return TRUE, if a != b (Conway's definition)
//
// AXIOM:	a != b	<==>  a !<= b  or  a !>= b
// THEOREM:	a == a

tBool NumNE (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && (!NumLE (a, b) || !NumLE (b, a));
}



// Return TRUE, if a ? b (Conway's definition)
//
// AXIOM:	a ? b	<==>  a !<= b  and  a !>= b
// THEOREM:	a !? a

tBool NumFUZ (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a != b && !NumLE (a, b) && !NumLE (b, a);
}



// Return TRUE, if a !? b (Not Fuzzy; Conway's definition)
//
// AXIOM:	a !? b	<==>  a <= b  or  a >= b
// THEOREM:	a !? a

tBool NumNF (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a == b || NumLE (a, b) || NumLE (b, a);
}



// Return TRUE, if a ?= b (Equal or Fuzzy; Conway's definition)
//
// AXIOM:	a ?= b	<==>  a <= b  xnor  a >= b
// THEOREM:	a ?= a

tBool NumEF (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return a == b || (!NumLE (a, b) ^ NumLE (b, a));
}



// Make a number out of two sets. (Conway's definition)
// The numbers is simplified as much as possible.
// If possible, an existing equivalent constant or variable is used instead.
//
// AXIOM:  	al == -ar	<==>	a == -a
// THEOREM:	c (a) <= (c (al) max c (ar)) + 1

tpNumber MakeNum (
	tpSet		l,		// Left set
	tpSet		r)		// Right set
{
	tNumber		t = tNumber (l, r);	// Temporary number template

	t.n_mat = &DummyMatrix;

	tpNumber	n;		// Newly-created number

	for (n = Numbers; n != NULLNumber; n = n->n_link) {
		if (n->n_day >= 0) {
			if (NumEQ (n, &t)) {	// Perform a real comparison
				return n;
			}
		}
	}

	tpSet		s;		// Temporary set
	tNodeDepth	day;		// Number age
	tNodeDepth	newest = -1;	// Newest day

	for (s = l; s != NULLSet; s = s->s_next) {
		if ((day = s->s_number->n_day) >= newest) {
			newest = day;
		}
	}

	for (s = r; s != NULLSet; s = s->s_next) {
		if ((day = s->s_number->n_day) >= newest) {
			newest = day;
		}
	}

	if (++newest >= DAY_ON) {
		newest = DAY_ON;
	}

	return AllocNum (l, r, newest);
}



// Get a named variable, optionally erasing it

tpNumber GetPerm (
	tString		name,		// name being requested
	tBool		erase)		// erase it?
{
	tppSet		sp;		// forward pointer
	tpSet		s;		// variable being examined

	for (sp = &Variables; (s = *sp) != NULLSet; sp = &s->s_next) {
		if (strcmp (s->s_name, name) == 0) {
			tpNumber	n = s->s_number;
			if (erase) {
				free (tpVoid (s->s_name));
				*sp = s->s_next;
				delete s;
			}
			return n;
		}
	}

	return NULLNumber;
}



// Assign a value to a named variable; name of variable is returned.

tcString MakePerm (
	tpNumber	n,		// value being assigned
	tcString	name)		// variable name being examined
{
	tpSet		s;		// variable being examined
	tppSet		sp;		// pointer to forward pointer

	for (sp = &Variables; (s = *sp) != NULLSet; sp = &s->s_next) {
		int		i = strcmp (name, s->s_name);
		if (i == 0) {		// re-define of old name
			s->s_number = n;
			return s->s_name;
		} else if (i < 0) {	// new name is before others: insert it here
			break;
		}
	}

	s = AllocSet (n, name);
	s->s_next = *sp;
	*sp = s;
	tString		newname = tString (xalloc (strlen (name)+1, TRUE));
	strcpy (newname, name);
	s->s_name = newname;
	nchars += strlen (s->s_name) + 1;
	s->s_number = n;
	return s->s_name;
}



// Assign a value to a named constant

void MakeConst (
	tpNumber	n,		// value being assigned
	tcString	name)		// variable name being examined
{
	n->n_name = MakePerm (n, name);
}



// Append a number to a set of numbers.  Duplicates are ignored.
// If desired, dominated values become replaced by their dominators.
// (sign>0 -> left-hand-set; sign<0 -> right-hand-set; sign=0 -> regular set)
// If both values are equal, the earliest value is preserved.
// Numbers are stored in order of increasing value (which may be somewhat
// unpredictable, if set contains values that are fuzzy with respect to each other).
// Among incomparable values, older values are stored first.
// (Such ordering is not mathematically necessary, but results in a visually
// more pleasing and consistent output.)

tBool AppendSet (
	tppSet		sp,		// pointer to set being added to
	tpNumber	n,		// number being added to set
	int		sign)		// domination direction
{
	tpSet		s;
	tppSet		spp;

	if (n == NULLNumber) {
		*sp = &ERRSet;
		return FALSE;
	}

	for (spp = sp; (s = *spp) != NULLSet; spp = &s->s_next) {	// Don't insert, if already there
		if (n == s->s_number) {
			return TRUE;
		}
	}

	if (sign > 0) {			// Add to left set:
		for (spp = sp; (s = *spp) != NULLSet; ) {
			if (NumLE (n, s->s_number)) {
				if (NumLE (s->s_number, n)) {	// both left equal:
					if (n->n_day < s->s_number->n_day) {	// both the same, but new one is older: replace old value
						*spp = s->s_next;
						if (s->s_next == NULLSet) {
							break;
						}
//						FreeSet (s);
					} else {		// both the same, but older one is older: keep old value
						return TRUE;	// (same if both are the same age, but this cannot happen)
					}
				} else {			// left dominated: ignore new value
					return TRUE;
				}
			} else {
				if (NumLE (s->s_number, n)) {	// left dominates: replace old value
					*spp = s->s_next;
					if (s->s_next == NULLSet) {
						break;
					}
//					FreeSet (s);
				} else {			// neither dominates: keep both values
					spp = &s->s_next;
					if (s->s_next == NULLSet) {
						break;
					}
				}
			}
		}
	} else if (sign < 0) {		// Add to right set:
		for (spp = sp; (s = *spp) != NULLSet; ) {
			if (NumLE (s->s_number, n)) {
				if (NumLE (n, s->s_number)) {	// both right equal:
					if (s->s_number->n_day < n->n_day) {	// Both the same, but new one is older: replace old value
						*spp = s->s_next;
						if (s->s_next == NULLSet) {
							break;
						}
//						FreeSet (s);
					} else {		// both the same, but older one is older: keep old value
						return TRUE;	// (same if both are the same age, but this cannot happen)
					}
				} else {			// right dominated: ignore new value
					return TRUE;
				}
			} else {
				if (NumLE (n, s->s_number)) {	// right dominates: replace old value
					*spp = s->s_next;
					if (s->s_next == NULLSet) {
						break;
					}
//					FreeSet (s);
				} else {			// neither dominates: keep both values
					spp = &s->s_next;
					if (s->s_next == NULLSet) {
						break;
					}
				}
			}
		}
	} else {			// Add to regular set:
		for (spp = sp; (s = *spp) != NULLSet; ) {
			if (NumEQ (n, s->s_number)) {		// both equal:
				if (n->n_day < s->s_number->n_day) {	// both the same, but new one is older: replace old value
					*spp = s->s_next;
					if (s->s_next == NULLSet) {
						break;
					}
//					FreeSet (s);
				} else {			// both the same, but older one is older: keep old value
					return TRUE;		// (same if both are the same age, but this cannot happen)
				}
			} else {
				spp = &s->s_next;
				if (s->s_next == NULLSet) {
					break;
				}
			}
		}
	}

	// At this point, dominated items have been eliminated.
	// We are going to insert the number; the following code just
	// determines the most aesthetically pleasing place to do so.

	for (; (s = *sp) != NULLSet && s->s_next != NULLSet; sp = &s->s_next) {
		if (NumLE (n, s->s_number)) {		// n is smaller than the rest of the set: insert here.
			break;				// (equality can't happen, because it's already been eliminated above)
		} else if (NumLE (s->s_number, n)) {	// n is larger than the first value: skip and try again
			if (s->s_next != NULLSet) {
				continue;
			}
			// NEVER alter a number's own set's forward link!!
			*sp = &n->n_set;		// Instead of inserting a new copy of n after archetype of s,
			n = s->s_number;		// we insert a new copy of s before archetype of n.
			break;
		} else if (n->n_day < s->s_number->n_day) {	// n is fuzzy with first element: put oldest first
			break;				// (if they are both the same age (e.g. {1|-2},{2|-1}), order is unpredictable.)
		}
	}

	if (*sp == NULLSet) {		// Add to empty set: new 1-element set
		s = &n->n_set;
	} else {
		s = AllocSet (n, NULLstring);
		s->s_next = *sp;
	}

	*sp = s;
	return TRUE;
}



// Append to a set the result of a unary operation on a set (or part thereof)

tBool AppendUnary (
	tppSet		s,		// pointer to set being added to
	tpNumber 	(*f) (tpNumber), // operator applied to each operand
	tpSet		r,		// list of operands of operator
	int		sign)		// domination direction
{
	for (; r != NULLSet; r = r->s_next) {
		if (!AppendSet (s, (*f) (r->s_number), sign)) {
			return FALSE;
		}
	}
	return TRUE;
}



// Append to a set the result of an operation between a scalar and a set

tBool AppendRight (
	tppSet		s,		// pointer to set being added to
	tpNumber 	(*f) (tpNumber, tpNumber), // operator applied to pair
	tpNumber	l,		// scalar left-operand of operator
	tpSet		r,		// list of right-operands of operator
	int		sign)		// domination direction
{
	for (; r != NULLSet; r = r->s_next) {
		if (!AppendSet (s, (*f) (l, r->s_number), sign)) {
			return FALSE;
		}
	}
	return TRUE;
}



// Append to a set the result of an operation between a set and a scalar

tBool AppendLeft (
	tppSet		s,		// pointer to set being added to
	tpNumber	(*f) (tpNumber, tpNumber), // operator applied to pair
	tpSet		l,		// list of left-operands of operator
	tpNumber	r,		// scalar right-operand of operator
	int		sign)		// domination direction
{
	for (; l != NULLSet; l = l->s_next) {
		if (!AppendSet (s, (*f) (l->s_number, r), sign)) {
			return FALSE;
		}
	}
	return TRUE;
}



// Append to a set the result of an operation between two sets

tBool AppendBinary (
	tppSet		s,		// pointer to set being added to
	tpNumber	(*f) (tpNumber, tpNumber), // operator applied to pair
	tpSet		l,		// list of left-operands of operator
	tpSet		r,		// list of right-operands of operator
	int		sign)		// domination direction
{
	for (; l != NULLSet; l = l->s_next) {
		tpSet		p;		// current right-operand
		for (p = r; p != NULLSet; p = p->s_next) {
			if (!AppendSet (s, (*f) (l->s_number, p->s_number), sign)) {
				return FALSE;
			}
		}
	}
	return TRUE;
}



// Make an exact duplicate of an entire set

tpSet CloneSet (
	tpSet		s)		// Set to be cloned
{
	tpSet		p;		// Tail of clone set
	tpSet		c;		// Head of clone set
	tppSet		cp;		// Pointer to forward-ptr in clone set

	for (cp = &c; s != NULLSet; s = s->s_next, cp = &p->s_next) {
		if (s == &s->s_number->n_set) {	// Don't need to clone final self-reference
			*cp = s;
			break;
		}
		*cp = p = AllocSet (s->s_number, NULLstring);
	}

	*cp = NULLSet;
	return c;
}



// Combine two sets together, removing dominated values

tpSet MixSets (
	tpSet		l,		// Left set being added
	tpSet		r,		// Right set being added
	int		sign)		// Domination direction
{
	tpSet		s;		// Head of set being added to

	for (s = NULLSet; l != NULLSet; l = l->s_next) {
		if (!AppendSet (&s, l->s_number, sign)) {
			return &ERRSet;
		}
	}

	for (; r != NULLSet; r = r->s_next) {
		if (!AppendSet (&s, r->s_number, sign)) {
			return &ERRSet;
		}
	}

	return s;
}



// Leave a number as-is:	a
// AXIOM:	a	=	a
// THEOREM:	c (a)	=	c (a)

tpNumber SelfNum (
	tpNumber	n)		// Single operand
{
	return n;
}



// Negate a number:  -a (Conway's definition)
//
// AXIOM:	-a	=	{-ar|-al}
// THEOREM:	- (-a)	=	a
// THEOREM:	c (-a)	=	c (a)

tpNumber NegNum (
	tpNumber	n)		// Single operand
{
#if 1
	if (n->n_neg != NULLNumber) {	// All numbers now remember their negatives
		return n->n_neg;
	}
#else
	tpVector	v;		// Pre-computed instruction vector

	v = OpVector (n, VT_NEG);

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}
#endif

	tpSet		l = NULLSet;	// Newly-created left-set
	tpSet		r = NULLSet;	// Newly-created right-set

	if (!AppendUnary (&l, NegNum, n->n_right, 1) ||
	    !AppendUnary (&r, NegNum, n->n_left, -1)) {
		return NULLNumber;
	}

#if 1
	tpNumber	q = MakeNum (l, r);
	n->n_neg = q;
	q->n_neg = n;
	return q;
#else
	return v->v_num = MakeNum (l, r);
#endif
}



// Convert an integer into a Number (NOTE: This should be cached!)

tpNumber IntToNum (
	tNodeDepth	n)
{
	if (n == 0) {
		return N_0;
	} else if (n == 1) {
		return N_1;
	} else if (n == -1) {
		return N_n1;
	} else if (n > 0) {
		return MakeNum (&IntToNum (n-1)->n_set, NULLSet);
	} else {
		return MakeNum (NULLSet, &IntToNum (n+1)->n_set);
	}
}



// Get day:  &a = day (a)

tpNumber DayNum (
	tpNumber	n)		// Single operand
{
	if (n->n_day >= DAY_ON) {	// on, off, dud: day=on
		return N_on;
	}
	return IntToNum (n->n_day);
}



// Add two numbers:  a + b (Conway's definition)
//
// AXIOM:	a + b	=	{al+b,a+bl|ar+b,a+br}
// THEOREM:	a + a	=	{al+a|ar+a}
// THEOREM:	a + -a	=	0	(NOT true for loopy games!)
// THEOREM:	a + 0	=	0 + a	=	0
// THEOREM:	dud + a	=	a + dud =	dud
// THEOREM:	on + off =	off + on =	dud
// THEOREM:	on + a	=	a + on	=	on
// THEOREM:	off + a	=	a + off	=	off
// THEOREM:	c (a+b)	<=	c (a) + c (b)

tpNumber AddNum (
	tpNumber	a,		// Left operand
	tpNumber	b)		// Right operand
{
	if (a == N_0) {			// 0 + b = b
		return b;
	} else if (b == N_0) {		// a + 0 = a
		return a;
	} else if (a == N_dud || b == N_dud) {	// dud + b = a + dud = dud
		return N_dud;
	} else if (a == N_on) {
		if (b == N_off) {	// on + off = dud
			return N_dud;
		} else {		// on + b = on
			return a;
		}
	} else if (a == N_off) {
		if (b == N_on) {	// off + on = dud
			return N_dud;
		} else {		// off + b = off
			return a;
		}
	} else if (b == N_on || b == N_off) {	// a + on = on; a + off = off;
		return b;
	}

	tpVector	v = OpCommute (a, b, VT_ADD);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set

	if (!AppendRight (&l, AddNum, a, b->n_left, 1)) {
		return NULLNumber;
	}

	tpSet		r = NULLSet;	// Newly-created right-set

	if (!AppendRight (&r, AddNum, a, b->n_right, -1)) {
		return NULLNumber;
	}

	if (a != b) {
		if (!AppendLeft (&l, AddNum, a->n_left, b, 1) ||
		    !AppendLeft (&r, AddNum, a->n_right, b, -1)) {
			return NULLNumber;
		}
	}

	return v->v_num = MakeNum (l, r);
}



// Subtract two numbers:  a + b (Conway's definition)
//
// AXIOM:	a - b	=	a + (-b)
// THEOREM:	a - b	=	{al-b,a-br|ar-b,b-al} (Is this really true?)
// THEOREM:	a - -a	=	a + a
// THEOREM:	a - a	=	0	(Not true for loopy games!)
// THEOREM:	0 - a	=	-a
// THEOREM:	a - 0	=	a
// THEOREM:	dud - a	=	a - dud =	dud
// THEOREM:	on - on =	off - off =	dud
// THEOREM:	on - a	=	a - off =	on
// THEOREM:	off - a	=	a - on =	off
// THEOREM:	c (a-b)	<=	c (a) + c (b)

tpNumber SubNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	if (a == N_dud || b == N_dud) {	// dud - b = a - dud = dud
		return N_dud;
	} else if (a == b) {
		if (a == N_on || a == N_off) {	// on - on = off - off = dud
			return N_dud;
		} else {		// a - a = 0
			return N_0;
		}
	} else if (a == N_0) {		// 0 - b = b
		return NegNum (b);
	} else if (b == N_0) {		// a - 0 = a
		return a;
	} else if (a == N_on || b == N_on) {	// on - b = on; off - b = off;
		return a;
	} else if (b == N_on) {		// a - on = off;
		return N_off;
	} else if (b == N_off) {	// a - off = on;
		return N_on;
	}

	tpVector	v = OpMatrix (a, b, VT_SUB);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set

	if (!AppendRight (&l, SubNum, a, b->n_right, 1) ||
	    !AppendLeft (&l, SubNum, a->n_left, b, 1)) {
		return NULLNumber;
	}

	tpSet		r = NULLSet;	// Newly-created right-set

	if (!AppendRight (&r, SubNum, a, b->n_left, -1) ||
	    !AppendLeft (&r, SubNum, a->n_right, b, -1)) {
		return NULLNumber;
	}

	return v->v_num = MakeNum (l, r);
}



// Not a number:  !a (Niemiec's definition - from J)
//
// AXIOM:	!a	=	1 - a

tpNumber NotNum (
	tpNumber	n)		// Single operand
{
	return SubNum (N_1, n);
}



// Ordinal sum of two numbers:  a : b (Conway's definition)
//
// AXIOM:	a : b	=	{al,a:bl|ar,a:br}
// THEOREM:	a : 0	=	a
// THEOREM:	0 : b	=	b
// THEOREM:	on : on	=	on
// THEOREM:	off : off =	off
// THEOREM:	dud : b	=	dud
// THEOREM:	on : dud =	{on|self}	<= currently unimplemented loopy game!
// THEOREM:	off : dud =	{self|off}	<= currently unimplemented loopy game!
// THEOREM:	a : dud	=	{al,self|ar,self}	<= currently unimplemented loopy game!
// THEOREM:	off : on =	{self|off}	<= currently unimplemented loopy game!
// THEOREM:	a : on	=	{self,al|ar}	<= currently unimplemented loopy game!
// THEOREM:	on : off =	{on|self}	<= currently unimplemented loopy game!
// THEOREM:	a : off	=	{al|self,ar}	<= currently unimplemented loopy game!
// THEOREM:	on : b	=	{on|on:br} = on?
// THEOREM:	off : b	=	{off:br|off} = off?
// THEOREM:	c (a:b)	<=	c (a) + c (b)

tpNumber OrdNum (
	tpNumber	a,		// Left operand
	tpNumber	b)		// Right operand
{
	if (a == N_0) {			// 0 : b = b
		return b;
	} else if (b == N_0) {		// a : 0 = a
		return a;
	} else if (a == N_dud) {	// dud : b = dud
		return a;
	} else if (b == N_dud) {	// a : dud = {al,self|ar,self}
		return Loopy ();
	} if (a == N_on) {
		if (b == N_off) {	// on : off = {on|self}
			return Loopy ();
		} else {		// on : on = on; on : b = {on|on} = on
			return a;
		}
	} else if (a == N_off) {
		if (b == N_on) {	// off : on = {self|off}
			return Loopy ();
		} else {		// off : off = off; off : b = {off|off} = off
			return a;
		}
	} else if (b == N_on || b == N_off) {	// a : on = {self,al|ar}; a : off = {al|self,ar}
		return Loopy ();
	}

	tpVector	v = OpMatrix (a, b, VT_ORD);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = CloneSet (a->n_left);	// Newly-created left-set

	if (!AppendRight (&l, OrdNum, a, b->n_left, 1)) {
		return NULLNumber;
	}

	tpSet		r = CloneSet (a->n_right);	// Newly-created right-set

	if (!AppendRight (&r, OrdNum, a, b->n_right, -1)) {
		return NULLNumber;
	}

	return v->v_num = MakeNum (l, r);
}



// Peform one quadrant of a multiplication:  al.b + bl.a - al.bl

tpNumber	MulNum (tpNumber a, tpNumber b);

tBool MulPart (
	tppSet		lp,
	tppSet		rp,
	tpNumber	a,
	tpSet		al,
	tpNumber	b,
	tpSet		bl)
{
	tpSet		p;

	for (p = al; p != NULLSet; p = p->s_next) {
		tpNumber	alb = MulNum (p->s_number, b);
		tpSet		q;
		for (q = bl; q != NULLSet; q = q->s_next) {
			tpNumber	bla = MulNum (a, q->s_number);
			tpNumber	albl = MulNum (p->s_number, q->s_number);
			tpNumber	x = SubNum (AddNum (alb,bla), albl);
			if (lp != NULLSetP) {
				if (!AppendSet (lp, x, 1)) {
					return FALSE;
				}
			}
			if (rp != NULLSetP) {
				if (!AppendSet (rp, x, -1)) {
					return FALSE;
				}
			}
		}
	}

	return TRUE;
}



// Return an appropriately-sized huge number, based on sign of a, and sign

tpNumber HugeNum (
	tpNumber	a,		// Number
	int		sign)
{
	if (NumLE (a, N_0)) {
		if (NumLE (N_0, a)) {	// a = 0: zero (shouldn't ever happen)
			return N_0;
		} else {		// a < 0: off (or on)
			sign = -sign;
		}
	} else {
		if (NumLE (N_0, a)) {	// a > 0: on (or off)
		} else {		// a ? 0: dud
			return N_dud;
		}
	}
	if (sign < 0) {
		return N_off;
	} else {
		return N_on;
	}
}



// Multiply two numbers:  a . b (Conway's definition)
//
// AXIOM:	a . b	= {al.b+bl.a-al.bl,ar.b+br.a-ar.br|
//			   al.b+br.a-al.br,ar.b+bl.a-ar.bl}
// (NOTE: This is defined for numbers, but doesn't work properly for non-numbers)
// THEOREM:	a* . b	= {al.b+bl.a-al.bl,al.b+br.a-al.br}*
// THEOREM:	a . b*	= {al.b+bl.a-al.bl,ar.b+bl.a-ar.bl}*
// THEOREM:	a* . b*	= {al.b+bl.a-al.bl}*
// THEOREM:	a . a	= {2.al.a-al.al,2.ar.a-ar.ar|al.a+ar.a-al.ar}
// THEOREM:	a . 0	=	0 . a	=	0
// THEOREM:	a . 1	=	1 . a	=	a
// THEOREM:	a . -1	=	-1 . a	=	-a
// THEOREM:	on . a	=	a . on =	on if a>0, off if a<0, dud if a?0
// THEOREM:	off . a	=	a . off =	off if a>0, on if a<0, dud if a?0
// THEOREM:	dud . a	=	a . dud =	dud if a!=0
// THEOREM:	c (a*b)	<=	c (a) * c (b)

tpNumber MulNum (
	tpNumber	a,		// Left operand
	tpNumber	b)		// Right operand
{
	if (a == N_0 || b == N_0) {	// a . 0 = 0 . b = 0
		return N_0;
	} else if (a == N_1) {		// 1 . b = b
		return b;
	} else if (b == N_1) {		// a . 1 = a
		return a;
	} else if (a == N_n1) {		// -1 . b = -b
		return NegNum (b);
	} else if (b == N_n1) {		// a . -1 = -a
		return NegNum (a);
	} else if (a == N_dud || b == N_dud) {	// dud . b = a . dud = dud
		return N_dud;
	} else if (a == N_on) {		// on . b = b>0 ? on : (b<0 ? off : dud)
		return HugeNum (b, 1);
	} else if (a == N_off) {	// off . b = b>0 ? off : (b<0 ? on : dud)
		return HugeNum (b, -1);
	} else if (b == N_on) {		// a . on = a>0 ? on : (a<0 ? off : dud)
		return HugeNum (a, 1);
	} else if (b == N_off) {	// a . off = a>0 ? off : (a<0 ? on : dud)
		return HugeNum (a, -1);
	}

	tpVector	v = OpCommute (a, b, VT_MUL);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set
	tpSet		r = NULLSet;	// Newly-created right-set
	tBool		nimb = a->n_left == a->n_right || b->n_left == b->n_right;	// Is result a nimber?

	if (!MulPart (&l, nimb?&r:NULLSetP, a, a->n_left, b, b->n_left)) {
		return NULLNumber;
	}

	if (a->n_left != a->n_right || b->n_left != b->n_right) {
		if (!MulPart (&l, nimb?&r:NULLSetP, a, a->n_right, b, b->n_right)) {
			return NULLNumber;
		}
	}

	if (!nimb) {
		if (!MulPart (NULLSetP, &r, a, a->n_left, b, b->n_right)) {
			return NULLNumber;
		}
		if (a->n_left != a->n_right || b->n_left != b->n_right) {
			if (!MulPart (NULLSetP, &r, a, a->n_right, b, b->n_left)) {
				return NULLNumber;
			}
		}
	}

	return v->v_num = MakeNum (l, r);
}



// Peform one quadrant of a Norton multiplication:  al..b +- i

tBool NMulPart (
	tppSet		lp,
	tpNumber	(*f) (tpNumber, tpNumber),
	tpSet		al,
	tpNumber	b,
	tpSet		i,
	int		sign)
{
	tpSet		p;

	for (p = al; p != NULLSet; p = p->s_next) {
		tpNumber	alb = MulNum (p->s_number, b);
		tpSet		q;
		for (q = i; q != NULLSet; q = q->s_next) {
			if (!AppendSet (lp, (*f) (alb,q->s_number), sign)) {
				return FALSE;
			}
		}
	}

	return TRUE;
}



// Peform one quadrant of a pseudo-Norton multiplication:  al..b + bl..a - al..bl

tpNumber NMulNum (tpNumber a, tpNumber b);

tBool MulNPart (
	tppSet		lp,
	tppSet		rp,
	tpNumber	a,
	tpSet		al,
	tpNumber	b,
	tpSet		bl)
{
	tpSet		p;

	for (p = al; p != NULLSet; p = p->s_next) {
		tpNumber	alb = NMulNum (p->s_number, b);
		tpSet		q;
		for (q = bl; q != NULLSet; q = q->s_next) {
			tpNumber	bla = NMulNum (a, q->s_number);
			tpNumber	albl = NMulNum (p->s_number, q->s_number);
			tpNumber	x = SubNum (AddNum (alb,bla), albl);
			if (lp != NULLSetP) {
				if (!AppendSet (lp, x, 1)) {
					return FALSE;
				}
			}
			if (rp != NULLSetP) {
				if (!AppendSet (rp, x, -1)) {
					return FALSE;
				}
			}
		}
	}

	return TRUE;
}



// Multiply two numbers:  a .. b (Norton's definition)
//
// AXIOM:	a .. b	=	{al..b+ (bl,2b-br)|ar..b- (bl,2b-br)}
//				(if a is non-integer, and b is positive)
// AXIOM:	a .. b	=	a . b
//				(if both a and b are integers)
// THEOREM:	a .. b	=	b .. a
// THEOREM:	a .. 0	=	0 .. a	=	0
// THEOREM:	a .. 1	=	1 .. a	=	a
// THEOREM:	a .. -1	=	-1 .. a	=	-a
// THEOREM:	a .. -b	=	-a .. b	=	- (a .. b)
// THEOREM:	c (a*b)	<=	c (a) * c (b)

tpNumber NMulNum (
	tpNumber	a,		// Left operand
	tpNumber	b)		// Right operand
{
	if ((a->n_left == NULLSet || a->n_right == NULLSet) &&
	    (b->n_left == NULLSet || b->n_right == NULLSet)) {	// Same as normal multiplication, for integers
		return MulNum (a, b);
	} else if (a == N_0 || b == N_0) {	// a .. 0 = 0 .. b = 0
		return N_0;
	} else if (a == N_1) {		// 1 .. b = b
		return b;
	} else if (b == N_1) {		// a .. 1 = a
		return a;
	} else if (a == N_n1) {		// -1 .. b = -b
		return NegNum (b);
	} else if (b == N_n1) {		// a .. -1 = -a
		return NegNum (a);
	} else if (a == N_dud || b == N_dud) {	// dud .. b = a .. dud = dud
		return N_dud;
	} else if (a == N_on) {		// on .. b = b>0 ? on : (b<0 ? off : dud)
		return HugeNum (b, 1);
	} else if (a == N_off) {	// off .. b = b>0 ? off : (b<0 ? on : dud)
		return HugeNum (b, -1);
	} else if (b == N_on) {		// a .. on = a>0 ? on : (a<0 ? off : dud)
		return HugeNum (a, 1);
	} else if (b == N_off) {	// a .. off = a>0 ? off : (a<0 ? on : dud)
		return HugeNum (a, -1);
	}

	tpVector	v = OpCommute (a, b, VT_NMUL);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	if (NumLE (b, N_0)) {
		return v->v_num = NegNum (NMulNum (a, NegNum (b)));
	} else if (NumLE (a, N_0)) {
		return v->v_num = NegNum (NMulNum (NegNum (a), b));
	}

	if (a->n_left == NULLSet || a->n_right == NULLSet) {
		if (b->n_left == NULLSet || b->n_right == NULLSet) {
			// a and b are both integers
			return v->v_num = MulNum (a, b);
		} else {
			// b is not an integer, and a is positive (and an integer)
			return v->v_num = NMulNum (b, a);
		}
	}

	tpSet		l = NULLSet;	// Newly-created left-set
	tpSet		r = NULLSet;	// Newly-created right-set

	if (NumGE (b, N_0)) {
		// a is not an integer, and b is positive: Norton Multiplication
		tpSet		s = CloneSet (b->n_left);	// Temporary set bl,2b-br
		if (!AppendRight (&s, SubNum, AddNum (b, b), b->n_right, 1)) {
			return NULLNumber;
		}
		if (!NMulPart (&l, AddNum, a->n_left, b, s, 1) ||
		    !NMulPart (&r, SubNum, a->n_right, b, s, -1)) {
			return NULLNumber;
		}
		return v->v_num = MakeNum (l, r);
	} else if (NumGE (a, N_0)) {
		// b may or may not be an integer, and a is positive
		return v->v_num = NMulNum (b, a);
	} else {	// TBD: ## We don't know how to multiply two fuzzies yet!
		tBool		nimb = a->n_left == a->n_right || b->n_left == b->n_right;	// Is result a nimber?

		if (!MulNPart (&l, nimb?&r:NULLSetP, a, a->n_left, b, b->n_left)) {
			return NULLNumber;
		}
		if (a->n_left != a->n_right || b->n_left != b->n_right) {
			if (!MulNPart (&l, nimb?&r:NULLSetP, a, a->n_right, b, b->n_right)) {
				return NULLNumber;
			}
		}

		if (!nimb) {
			if (!MulNPart (NULLSetP, &r, a, a->n_left, b, b->n_right)) {
				return NULLNumber;
			}
			if (a->n_left != a->n_right || b->n_left != b->n_right) {
				if (!MulNPart (NULLSetP, &r, a, a->n_right, b, b->n_left)) {
					return NULLNumber;
				}
			}
		}

		return v->v_num = MakeNum (l, r);
	}
}



// Maximum of two numbers:  a >> b (Niemiec's new definition)
//
// AXIOM:	a >> b =	b			(if a <= b)
// AXIOM:	a >> b =	a			(if a >= b)
// AXIOM:	a >> b =	{al,bl|ar>>br}		(if ar,br aren't empty)
// AXIOM:	a >> b =	{al|b*}			(if br is empty but ar is not)
// AXIOM:	a >> b =	{bl|a*}			(if ar is empty but br is not)
// THEOREM:	a >> b =	- (-a << -b)
// THEOREM:	a >> a	=	a
// THEOREM:	a >> b	=	b >> a
// THEOREM:	on >> a =	a >> on =	on
// THEOREM:	off >> a =	a >> off =	a
// THEOREM:	for all x, x<=a => x<=a>>b
// THEOREM:	for all x, x>=a and x>=b => x>=a>>b
// ?THEOREM:	c (a>>b)	<=	c (a) max c (b)

tpNumber MaxNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	if (a == b) {			// a >> a = a
		return a;
	} else if (a == N_on || b == N_off) {	// on >> b = on; a >> off = a
		return a;
	} else if (b == N_on || a == N_off) {	// a >> on = on; off >> b = b
		return b;
	} else if (NumLE (a, b)) {	// a <= b: a >> b = b
		return b;
	} else if (NumLE (b, a)) {	// a >= b: a >> b = a
		return a;
	}				// a ? b: it gets complicated...

	tpVector	v = OpCommute (a, b, VT_MAX);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		r = NULLSet;	// Newly-created right-set
	tpSet		l;		// Newly-created left-set

	if (a->n_right == NULLSet) {			// a={al|}>>b={bl|br} => {bl|a*}
		l = b->n_left;
		if (!AppendSet (&r, AddNum (a, N_star), -1)) {
			return NULLNumber;
		}
	} else if (b->n_right == NULLSet) {		// a={al|ar}>>b={bl|} => {al|b*}
		l = a->n_left;
		if (!AppendSet (&r, AddNum (b, N_star), -1)) {
			return NULLNumber;
		}
	} else {
		l = MixSets (a->n_left, b->n_left, 1);
		if (l == &ERRSet ||
		    !AppendBinary (&r, MaxNum, a->n_right, b->n_right, -1)) {
			return NULLNumber;
		}
	}						// Both null can't happen - two ordinals are guaranteed to be <= or >= each other)

	return v->v_num = MakeNum (l, r);
}



// Minimum of two numbers:  a << b (Niemiec's definition)
//
// THEOREM:	a << b	=	- (-a >> -b)

tpNumber MinNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	return NegNum (MaxNum (NegNum (a), NegNum (b)));
}



// Absolute value of a number:  >>a (Niemiec's definition)
// AXIOM:	>>a	=	a >> -a
// THEOREM:	c (>>a)	=	c (a)

tpNumber AbsNum (
	tpNumber	n)		// right operand
{
	return MaxNum (n, NegNum (n));
}



// Negative absolute value of a number:  <<a (Niemiec's definition)
// AXIOM:	<<a	=	a << -a
// THEOREM:	<<a	=	- (>>a)
// THEOREM:	c (<<a)	=	c (a)

tpNumber NAbsNum (
	tpNumber	n)		// right operand
{
	return NegNum (AbsNum (n));
}



// Convert a Number into an integer
// (CAVEAT: Non-integers will return an unpredictable result!)

int NumToInt (
	tpNumber	n)		// right operand
{
	tpSet		s;		// set (only one element assumed)
	int		i;		// estimated value

	for (i = 0; ; ) {
		if (n->n_left == NULLSet) {
			if (n->n_right == NULLSet) {	// "{ | }" = 0
				break;
			} else {			// "{ | r }" = r-1
				--i;
				s = n->n_right;
			}
		} else {
			if (n->n_right == NULLSet) {	// " { l | }" = l+1
				++i;
				s = n->n_left;
			} else {			// "{ l | r }" is a fraction
				s = n->n_left;		// (this is NOT an integer, so just improvise)
			}
		}

		if (s == NULL) {
			break;
		}

		n = s->s_number;
	}

	return i;
}



// Generate a nimber:  .a = *[a]
// AXIOM:	*a is only defined for integer values of a
// AXIOM:	*a	=	{ *0 *1 ... *a-1 | *0 *1 ... *a-1 }
// AXIOM:	*-a	=	- *a = *a
// THEOREM:	*0	=	0
// THEOREM:	*on	=	*off	=	*dud	=	dud
// (NOTE: This COULD theoretically be expanded to some select non-integers,
//  but that is much more complicated than is curently worth the effort here.
//  In particular, *n/2 = { *n (0|*n) | 0 v*} and *-n/2 = { 0 ^* | *n (*n|0) } )

tpNumber StarInt (
	int		n)		// right operand
{
	if (n < 0) {			// * -a = * a
		n = -n;
	} else if (n == 0) {		// * 0 = 0
		return N_0;
	}

	tpSet		l = NULLSet;	// Newly-created left-set
	int		i;

	for (i = 0; i < n; ++i) {
		if (!AppendSet (&l, StarInt (i), 0)) {
			return NULLNumber;
		}
	}

	return MakeNum (l, l);
}

tpNumber StarNum (
	tpNumber	n)		// right operand
{
	if (n == N_on || n == N_off || n == N_dud) {	// * on = * off = * dud = dud
		return N_dud;
	}

	return StarInt (NumToInt (n));
}



// Fast join of two numbers:  a & b (Conway's definition)
//
// AXIOM:	a & b	=	{al&bl|ar&br}
// THEOREM:	a & b	=	b & a
// THEOREM:	a & a	=	a
// THEOREM:	a & 0	=	0 & a	=	0
// THEOREM:	c (a&b)	<=	c (a) max c (b)
// CAVEAT:  This depends on form as well as value!
// THEOREM:	on & off =	0
// THEOREM:	dud & a	=	a & dud =	a


tpNumber AndNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	if (a == b) {			// a & a = a
		return a;
	} else if (a == N_0 || b == N_0) {	// a & 0 = 0 & b = 0
		return N_0;
	} else if (a == N_dud) {	// dud & b = b
		return b;
	} else if (b == N_dud) {	// a & dud = a
		return a;
	}

	tpVector	v = OpCommute (a, b, VT_AND);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set
	tpSet		r = NULLSet;	// Newly-created right-set

	if (!AppendBinary (&l, AndNum, a->n_left, b->n_left, 1) ||
	    !AppendBinary (&r, AndNum, a->n_right, b->n_right, -1)) {
		return NULLNumber;
	}

	return v->v_num = MakeNum (l, r);
}



// Slow join of two numbers:  a && b (Conway's definition)
//
// AXIOM:	a && b	=	{[al||bl||al&&bl]|[ar||br||ar&&br]}
// THEOREM:	a && b	=	b && a
// THEOREM:	a && a	=	a
// THEOREM:	a && 0	=	0 && a	=	a
// THEOREM:	on && off =	off && on =	dud
// THEOREM:	dud && a =	a && dud =	dud
// THEOREM:	c (a&&b) <=	c (a) max c (b)
// CAVEAT:  This depends on form as well as value!

tpNumber AlsoNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	if (a == N_0) {			// 0 && b = a && b = b
		return b;
	} else if (b == N_0) {		// a && 0 = a
		return a;
	} else if (a == N_dud) {	// dud && b = dud
		return a;
	} else if (b == N_dud) {	// a && dud = dud
		return b;
	} else if (a == N_on) {
		if (b == N_off) {	// on && off = dud
			return N_dud;
		}
	} else if (a == N_off) {
		if (b == N_on) {	// off && on = dud
			return N_dud;
		}
	}

	tpVector	v = OpMatrix (a, b, VT_ALSO);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set

	if (a->n_left == NULLSet) {
		l = b->n_left;
	} else if (b->n_left == NULLSet) {
		l = a->n_left;
	} else {
		l = MixSets (a->n_left, b->n_left, 1);
		if (l == &ERRSet ||
		    !AppendBinary (&l, AlsoNum, a->n_left, b->n_left, 1)) {
			return NULLNumber;
		}
	}

	tpSet		r = NULLSet;	// Newly-created right-set

	if (a->n_right == NULLSet) {
		r = b->n_right;
	} else if (b->n_right == NULLSet) {
		r = a->n_right;
	} else {
		l = MixSets (a->n_left, b->n_left, -1);
		if (l == &ERRSet ||
		    !AppendBinary (&r, AlsoNum, a->n_right, b->n_right, -1)) {
			return NULLNumber;
		}
	}

	return v->v_num = MakeNum (l, r);
}



// Tardy union of two numbers:  a ! b (Conway's definition)
//
// AXIOM:	a ! b	=	{al!b,a!bl,al!bl|ar!b,a!br,ar!br}
// THEOREM:	a ! b	=	b ! a
// THEOREM:	a ! 0	=	0 ! a	=	a
// THEOREM:	c (a!b)	<=	c (a) + c (b)
// THEOREM:	on ! on	=	on
// THEOREM:	off ! off =	off
// THEOREM:	on ! off =	off ! on =	dud
// THEOREM:	dud ! b	=	b ! dud =	dud
// CAVEAT:  This depends on form as well as value!
tpNumber OrNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	if (a == N_0) {			// 0 ! b = b
		return b;
	} else if (b == N_0) {		// a ! 0 = a
		return a;
	} else if (a == N_dud) {	// dud ! b = dud
		return a;
	} else if (b == N_dud) {	// a ! dud = dud
		return b;
	} else if (a == N_on) {
		if (b == N_on) {	// on ! on = on
			return a;
		} else if (b == N_off) {	// on ! off = dud
			return N_dud;
		}
	} else if (a == N_off) {
		if (b == N_off) {	// off ! off = off
			return a;
		} else if (b == N_on) {	// off ! on = dud
			return N_dud;
		}
	}

	tpVector	v = OpCommute (a, b, VT_OR);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set

	if (!AppendLeft (&l, OrNum, a->n_left, b, 1) ||
	    !AppendRight (&l, OrNum, a, b->n_left, 1) ||
	    !AppendBinary (&l, OrNum, a->n_left, b->n_left, 1)) {
		return NULLNumber;
	}

	tpSet		r = NULLSet;	// Newly-created right-set

	if (!AppendLeft (&r, OrNum, a->n_right, b, -1) ||
	    !AppendRight (&r, OrNum, a, b->n_right, -1) ||
	    !AppendBinary (&r, OrNum, a->n_right, b->n_right, -1)) {
		return NULLNumber;
	}

	return v->v_num = MakeNum (l, r);
}



// Urgent union of two numbers:  a !! b (Conway's definition)
//
// AXIOM:	a !! b	=	{[al!!b,a!!bl,al!!bl]|[ar!!b,a!!br,ar!!br]}
// THEOREM:	a !! b	=	b !! a
// THEOREM:	a !! 0	=	0 !! a	=	0
// THEOREM:	on !! on  =	on
// THEOREM:	off !! off =	off
// THEOREM:	on !! dud =	dud !! on =	on
// THEOREM:	off !! dud =	dud !! off =	off
// THEOREM:	on !! off =	off !! on =	0
// THEOREM:	dud !! dud =	dud
// THEOREM:	c (a!!b)	<=	c (a) + c (b)
// CAVEAT:  This depends on form as well as value!

tpNumber UrNum (
	tpNumber	a,		// left operand
	tpNumber	b)		// right operand
{
	if (a == N_0 || b == N_0) {	// 0 !! b = a !! 0 = 0
		return N_0;
	} else if (a == N_on) {
		if (b == N_off) {	// on !! off = 0
			return N_0;
		} else if (b == N_on || b == N_dud) {	// on !! on = on !! dud = on
			return a;
		}
	} else if (a == N_off) {
		if (b == N_on) {	// off !! on = 0
			return N_0;
		} else if (b == N_off || b == N_dud) {	// off !! off = off !! dud = off
			return a;
		}
	} else if (a == N_dud) {
		if (b == N_dud || b == N_on || b == N_off) {	// dud !! dud = dud; dud !! on = on; dud !! off == offf
			return b;
		}
	}

	tpVector	v = OpCommute (a, b, VT_UR);	// Pre-computed instruction vector

	if (v->v_num != NULLNumber) {
		return v->v_num;
	}

	tpSet		l = NULLSet;	// Newly-created left-set

	if (a->n_left != NULLSet && b->n_left != NULLSet) {
		if (!AppendLeft (&l, UrNum, a->n_left, b, 1) ||
		    !AppendRight (&l, UrNum, a, b->n_left, 1) ||
		    !AppendBinary (&l, UrNum, a->n_left, b->n_left, 1)) {
			return NULLNumber;
		}
	}

	tpSet		r = NULLSet;	// Newly-created right-set

	if (a->n_right != NULLSet && b->n_right != NULLSet) {
		if (!AppendLeft (&r, UrNum, a->n_right, b, -1) ||
		    !AppendRight (&r, UrNum, a, b->n_right, -1) ||
		    !AppendBinary (&r, UrNum, a->n_right, b->n_right, -1)) {
			return NULLNumber;
		}
	}

	return v->v_num = MakeNum (l, r);
}



// Merge left sets of all operands

tpSet SetLeft (
	tpSet		x)
{
	if (x == NULLSet) {			// merge of null sets is null set
		return x;
	} else if (x->s_next == NULLSet) {	// merge of atoms is atom's set
		return x->s_number->n_left;
	} else {
		tpSet		s = NULLSet;
		for (; x != NULLSet; x = x->s_next) {
			if (!AppendUnary (&s, SelfNum, x->s_number->n_left, 0)) {
				return &ERRSet;
			}
		}
		return s;
	}
}



// Merge right sets of all operands

tpSet SetRight (
	tpSet		x)
{
	if (x == NULLSet) {			// merge of null sets is null set
		return x;
	} else if (x->s_next == NULLSet) {	// merge of atoms is atom's set
		return x->s_number->n_right;
	} else {
		tpSet		s = NULLSet;
		for (; x != NULLSet; x = x->s_next) {
			if (!AppendUnary (&s, SelfNum, x->s_number->n_right, 0)) {
				return &ERRSet;
			}
		}
		return s;
	}
}



// Compare two sets against each other

tBool SetRel (
	tBool		(*f) (tpNumber a, tpNumber b),	// operator
	tpSet		x,		// left set
	tpSet		y)		// right set
{
	for (; x != NULLSet; x = x->s_next) {
		tpSet		j;
		for (j = y; j != NULLSet; j = j->s_next) {
			if (! (*f) (x->s_number, j->s_number)) {
				return FALSE;
			}
		}
	}
	return TRUE;
}



// Display a number in human-readable form

void PrintSet (tpSet s);

tBool PrintNum (
	tpNumber	n,
	tBool		full)
{
	if (n->n_day < 0) {
		printf ("%s", lexsymbols[int (~n->n_day)]);
		return TRUE;
	}

	if (n->n_name != NULLstring) {
		printf ("%s", n->n_name);
		if (!full) {
			return TRUE;
		}
		printf (" = ");
	}

	printf ("{");
	PrintSet (n->n_left);
	printf ("|");
	PrintSet (n->n_right);
	printf ("}");

	if (full) {
		if (n->n_day >= DAY_ON) {
			printf (" [%s]", N_on->n_name);
		} else {
			printf (" [%ld]", n->n_day);
		}
	}

	return FALSE;
}



// Display a set of variables in human-readable form.

void PrintVars (
	tpSet		s)
{
	tcString	sep = "";

	for (; s != NULLSet; s = s->s_next) {
		printf ("%s%s", sep, s->s_name);
		sep = " ";
	}
}



// Display a set of numbers in human-readable form.
// Syntactic entities are not displayed.

void PrintSet (
	tpSet		s)
{
	tcString	sep = "";

	for (; s != NULLSet; s = s->s_next) {
		if (s->s_number->n_day >= 0) {
			printf (sep);
			if (PrintNum (s->s_number, FALSE)) {
				sep = " ";
			}
		}
	}
}



// Display a sub-set of all known variables which are related to a number
// (all less than, all equal to, all fuzzier with, or all greater than)

void PrintRel (
	tpSet		x,
	tcString	lstring,
	tcString	rstring,
	tBool		(*f) (tpNumber, tpNumber),
	int		sign)
{
	tpSet		s;
	tpSet		v;

	for (s = NULLSet, v = Variables; v != NULLSet; v = v->s_next) {
		if (v->s_number->n_day >= 0) {
			if (SetRel (f, &v->s_number->n_set, x)) {
				if (!AppendSet (&s, v->s_number, sign)) {
					return;
				}
			}
		}
	}

	if (s != NULLSet) {
		printf (lstring);
		PrintSet (s);
		printf (rstring);
	}
}



// Perform initializations
//
// AXIOM:	0	=	{|}
// AXIOM:	1	=	{0|}
// AXIOM:	-1	=	{|0}
// AXIOM:	*	=	{0|0}
// AXIOM:	on	=	{on|}
// AXIOM:	off	=	{|off}
// AXIOM:	dud	=	{dud|dud}
// THEOREM:	0	=	- 0
// THEOREM:	-1	=	- -1
// THEOREM:	off	=	- on
// THEOREM:	dud	=	- dud

void InitNum ()
{
	MakeConst (N_0 = AllocNum (NULLSet, NULLSet, 0), "0");
	N_0->n_neg = N_0;
	MakeConst (N_1 = AllocNum (&N_0->n_set, NULLSet, 1), "1");
	MakeConst (N_n1 = AllocNum (NULLSet, &N_0->n_set, 1), "_1");
	N_1->n_neg = N_n1;
	N_n1->n_neg = N_0;
	MakeConst (N_star = AllocNum (&N_0->n_set, &N_0->n_set, 1), "*");
	N_star->n_neg = N_star;

	MakeConst (N_on = AllocNum (&SELFSet, NULLSet, DAY_ON), "on");
	MakeConst (N_off = AllocNum (NULLSet, &SELFSet, DAY_ON), "off");
	N_on->n_neg = N_off;
	N_off->n_neg = N_on;
	MakeConst (N_dud = AllocNum (&SELFSet, &SELFSet, DAY_ON), "dud");
	N_dud->n_neg = N_dud;
}



//////////////////////////////////////////////////////////////////////////
//									//
// Calculator parser							//
//									//
//////////////////////////////////////////////////////////////////////////



// Global variables used by parser

FILE *		fin;			// current input stream
tBool		quiet = FALSE;		// suppress startup message?
tBool		verbose = FALSE;	// echo script as it's being executed?
ePrecedence	lexprio;		// operator precedence of L_BAR token
char		peekc = { ' ' };	// look-ahead character (or space)
eToken		peekt = { L_NULL };	// look-ahead token (or L_NULL)
eToken		peekt2 = { L_NULL };	// second look-ahead token (or L_NULL)
char		lexname[MAXNAME+1];	// name of variable or constant token

tNumber	Syntaxes[L_ALL] = {		// array of syntactical-entity pseudo-numbers
	tNumber (L_NULL), tNumber (L_EOL), tNumber (L_TERM), tNumber (L_LPAREN), tNumber (L_RPAREN),
	tNumber (L_LBRACE), tNumber (L_RBRACE), tNumber (L_SUMM), tNumber (L_ASG), tNumber (L_CASG),
	tNumber (L_BAR), tNumber (L_OR), tNumber (L_UR), tNumber (L_AND), tNumber (L_ALSO),
	tNumber (L_MAX), tNumber (L_MIN), tNumber (L_ADD), tNumber (L_SUB), tNumber (L_MUL),
	tNumber (L_ORD), tNumber (L_COMMA), tNumber (L_LT), tNumber (L_LE), tNumber (L_LF),
	tNumber (L_GT), tNumber (L_GE), tNumber (L_GF), tNumber (L_LG), tNumber (L_EQ),
	tNumber (L_NE), tNumber (L_FUZ), tNumber (L_NF), tNumber (L_EF), tNumber (L_NL),
	tNumber (L_NG), tNumber (L_CMP), tNumber (L_NMUL)
};



// Characters not allowed in identifiers
// (Note that identifiers may include letters, digits,
//  'printable' control-characters (such as  and ),
//  international characters (such as � � �),
//   $ * / @ ^ _
// The following characters are currently legal, but should be avoided:
//   ' "
// The following characters are not currently used, but are reserved for future use:
//   ; [ ] `

char punctChars[] = { "\t\n !&()+,-:;<=>?[]{|}~" };



// Read one character from the input stream

int Getcf (
	int		term)		// terminator character (or EOF, if none)
{
	int		c;		// character being read

	while ((c = getc (fin)) == EOF) {
		if (fin == stdin) {
			exit (0);
		}
		fclose (fin);
		fin = stdin;
		return '\n';		// add spurious, so next prompt is to console
	}

	if (c == term) {		// recognize terminator: do not eat or print it
		ungetc (c, fin);
	} else if (fin != stdin && verbose) {
		putchar (c);
	}

	return c;
}



// Lexical analyzer:
//
// The following tokens are recognized:
//
//	( )		Parentheses (prioritization)
//	{ }		Set definitions
//	| || ||| etc.	Set separators
//	=		Assignment
//	=:		Constant assignment
//	,		Concatenation
//	+		Addition
//	-		Subtraction		Negation
//	.		Multiplication
//	..		Norton's Multiplication
//	<=		Less or equal
//	>=		Greater or equal
//	?=		Equal or fuzzy
//	<		Less than
//	<>		Less or greater
//	<?		Less or fuzzy
//	>>		Maximum			Positive absolute
//	>		Greater than
//	>?		Greater or fuzzy
//	<<		Minimum			Negative absolute
//	|		Set separator
//	!		Union (OR)
//	!=		Not equal
//	!<		Not less
//	!>		Not greater
//	!?		Not fuzzy
//	!!		Urgent union
//	?		Fuzzy
//	?=		Fuzzy or Equal
//	??		Summary
//	&		And
//	&&		Also
//	:		Ordinal sum
//	::		Comparison
//	;		Start of comment

eToken GetLex ()
{
	eToken		t;		// backed-up token

	if ((t = peekt) != L_NULL) {
		peekt = peekt2;
		peekt2 = L_NULL;
		return t;
	}

	for (;; peekc = Getcf (EOF)) {
		char		i = peekc;	// backed-up character

		peekc = ' ';

		switch (i) {
		case ' ':
		case '\t':
			break;
		case '\n':
			peekc = '\n';
			return peekt = L_EOL;
		case '(':
			return L_LPAREN;
		case ')':
			return L_RPAREN;
		case '{':
			return L_LBRACE;
		case '}':
			return L_RBRACE;
		case '+':
			return L_ADD;
		case '-':
			return L_SUB;
		case ',':
			return L_COMMA;

		case '=':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_ASG;
			case '=':
				return L_EQ;
			case ':':
				return L_CASG;
			}

		case '<':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_LT;
			case '=':
				return L_LE;
			case '>':
				return L_LG;
			case '?':
				return L_LF;
			case '<':
				return L_MIN;
			}

		case '>':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_GT;
			case '=':
				return L_GE;
			case '?':
				return L_GF;
			case '>':
				return L_MAX;
			}

		case '?':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_FUZ;
			case '=':
				return L_EF;
			case '?':
				return L_SUMM;
			}

		case '|':
			lexprio = P_BAR;
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_BAR;
			case '|':
				do {
					lexprio = ePrecedence (lexprio-1);
				} while ((peekc = Getcf (EOF)) == '|');
				return L_BAR;
			}

		case '!':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_OR;
			case '=':
				return L_NE;
			case '<':
				return L_NL;
			case '>':
				return L_NG;
			case '?':
				return L_NF;
			case '!':
				return L_UR;
			}

		case '&':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_AND;
			case '&':
				return L_ALSO;
			}

		case ':':
			switch (i = Getcf (EOF)) {
			default:
				peekc = i;
				return L_ORD;
			case ':':
				return L_CMP;
			}

		case ';':				// ; comment
			while ((peekc = Getcf ('\n')) != '\n') {
			}
			continue;

		case '"':				// " message
			do {
				peekc = Getcf ('\n');
				if (!verbose) {
					putchar (peekc);
				}
			} while (peekc != '\n');
			continue;

		default:
			int		j;		// index into name
			for (j = 0; strchr (punctChars, i) == NULLstring; i = Getcf (EOF)) {
				if (j < MAXNAME) {
					lexname[j++] = i;
				}
			}
			lexname[j] = '\0';
			peekc = i;
			if (strcmp (lexname, ".") == 0) {
				return L_MUL;
			} else if (strcmp (lexname, "..") == 0) {
				return L_NMUL;
			}
			return L_TERM;
		}
	}
}



// Back up a token

void UnLex (
	eToken		t)		// token to back up
{
	peekt2 = peekt;
	peekt = t;
}



// Complain if a token is not present

tBool NeedLex (
	eToken		n)		// token we need
{
	eToken		t;		// token we got

	if ((t = GetLex ()) == n) {
		return TRUE;
	}

	printf ("Missing %s expected near %s\n", lexsymbols[n], lexsymbols[t]);
	return FALSE;
}



// Get an atomic expression

tpSet GetExpr (ePrecedence p);

tpNumber GetAtom (
	ePrecedence	p)		// operator priority
{
	tpSet		s;		// set containing atom

	if ((s = GetExpr (p)) == &ERRSet) {
		return NULLNumber;
	}

	if (s == NULLSet || s->s_next != NULLSet) {
		printf ("Assignment of sets is not allowed\n");
		return NULLNumber;
	}

	return s->s_number;
}



// Parse a Bar operation:  |, x|, |x, x|y, x||y, x|||y, etc.

tBool BarOp (
	ePrecedence	p,		// operator priority
	tppSet		xp)		// left operand and result
{
	tpSet		y;		// right-hand set
	eToken		i;		// peeked token

	UnLex (i = GetLex ());

	switch (i) {
	case L_BAR:
	case L_RPAREN:
	case L_RBRACE:
	case L_EOL:
		y = NULLSet;
		break;
	default:
		if ((y = GetExpr (ePrecedence (p+1))) == &ERRSet) {
			*xp = y;
			return FALSE;
		}
		break;
	}

	tpSet		l;		// New left set
	tpSet		r;		// New right set
	if ((l = MixSets (NULLSet, *xp, 1)) == &ERRSet ||
	    (r = MixSets (NULLSet, y, -1)) == &ERRSet) {
		*xp = &ERRSet;
		return FALSE;
	}

	*xp = &MakeNum (l, r)->n_set;
	return TRUE;
}



// Set Concatenation:  x,y

tBool CatOp (
	ePrecedence	p,		// operator priority
	tppSet		xp)		// left operand and result
{
	tpSet		y;		// right-hand set

	if ((y = GetExpr (p)) == &ERRSet) {
		// ### LEAK: we should free xp first!
		*xp = y;
		return FALSE;
	}

	*xp = MixSets (*xp, y, 0);
	return *xp != &ERRSet;
}



// Relative Comparison Operations:
// x<y, x>y, x<=y, x>=y, x<|y, x|>y, x==y, x!=y, x<>y, x?=y, x?y
// NOTE: Result is an atom reflecting set comparison, not item-by-item comparisons

tBool RelOp (
	ePrecedence	p,		// operator priority
	tppSet		xp,		// left operand and result
	tBool		(*f) (tpNumber a, tpNumber b))	// operator
{
	tpSet		y;		// right operand

	if ((y = GetExpr (ePrecedence (p+1))) == &ERRSet) {
		// ### LEAK: we should free xp first!
		*xp = y;
		return FALSE;
	}

	*xp = SetRel (f, *xp, y) ? &N_1->n_set : &N_0->n_set;
	return TRUE;
}



// Comparison Operation:  x::y		(Niemiec's definition)
//
// AXIOM:	x<y	<==>	x::y = -1
// AXIOM:	x>y	<==>	x::y = 1
// AXIOM:	x=y	<==>	x::y = 0
// AXIOM:	x?y	<==>	x::y = *
// THEOREM:	x::y	=	-(y::x)

tBool CmpOp (
	ePrecedence	p,		// operator priority
	tppSet		xp)		// left operand and result
{
	tpSet		y;		// right operand

	if ((y = GetExpr (ePrecedence (p+1))) == &ERRSet) {
		*xp = NULLSet;
		return FALSE;
	}

	int		i;		// mask of comparison types

	for (i = 0; y != NULLSet; y = y->s_next) {
		tpSet		x;		// left operand
		for (x = *xp; x != NULLSet; x = x->s_next) {
			if (NumLE (x->s_number, y->s_number)) {
				i |= NumLE (y->s_number, x->s_number) ? 8 : 4;
			} else {
				i |= NumLE (y->s_number, x->s_number) ? 2 : 1;
			}
		}
	}

	*xp = NULLSet;

	if (i & 1 && !AppendSet (xp, N_star, 0) ||
	    i & 2 && !AppendSet (xp, N_1, 0) ||
	    i & 4 && !AppendSet (xp, N_n1, 0) ||
	    i & 8 && !AppendSet (xp, N_0, 0)) {
		return FALSE;
	}

	return TRUE;
}



// Parse Unary Arithmetic Operations:
// +x, \+x, -x, \-x, \.x, >>x, <<x

tBool UnaryOp (
	ePrecedence	p,		// operator priority
	tppSet		xp,		// result
	tpNumber	(*f) (tpNumber a))	// operator
{
	tpSet		x;		// right operand

	if ((x = GetExpr (p)) == &ERRSet) {
		*xp = x;
		return FALSE;
	}

	*xp = NULLSet;
	return AppendUnary (xp, f, x, 0);
}



// Parse Binary Arithmetic Operations:
// x:y, x.y, x..y, x+y, x-y, x>>y, x<<y, x&y, x&&y, x!y, x!!y

tBool BinaryOp (
	ePrecedence	p,		// operator priority
	tppSet		xp,		// left operand and result
	tpNumber	(*f) (tpNumber a, tpNumber b)) // operator
{
	tpSet		y;		// right operand

	if ((y = GetExpr (p)) == &ERRSet) {
		// NOTE: LEAK: we should free *xp first!
		*xp = y;
		return FALSE;
	}

	tpSet		x = *xp;	// left operand

	*xp = NULLSet;
	return AppendBinary (xp, f, x, y, 0);
}



// See if at end of line or parenthesized expression

tBool AtEnd ()
{
	eToken		t = GetLex ();	// next token in stream
	UnLex (t);
	return t == L_RPAREN || t == L_RBRACE || t == L_EOL;
}



// Get a set expression
// Expressions may return operators, with two exceptions:
// | || etc. may not be used, as (|) = 0, which conflicts with use of (|) = |
// = and =. may not be used because x (=) y would require more complicated
// parsing rules.

tpSet GetExpr (
	ePrecedence	p)		// operator priority
{
	tpSet		x;		// left operand and result
	tpNumber	n;		// atomic value
	eToken		t;		// token being examined

	for (;;) {
		t = GetLex ();

		if (t >= L_ASSIGNABLE) {	// MUST NOT get 2 L_TERMS in a row; this trashes lexname!
			if (p >= P_HI || AtEnd ()) {	// non-numeric expression
				x = &Syntaxes[t].n_set;
				break;
			}
		}

		switch (t) {

		case L_LPAREN:
			if ((t = GetLex ()) == L_RPAREN) {	// ()	Empty set
				x = NULLSet;
			} else {
				UnLex (t);
				if ((x = GetExpr (P_LO)) == &ERRSet || !NeedLex (L_RPAREN)) {	// (y)	Parentheses
					return &ERRSet;
				}
			}
			break;

		case L_LBRACE:
			if ((t = GetLex ()) == L_RBRACE) {	// {}	Empty set
				x = NULLSet;
			} else {
				UnLex (t);
				if ((x = GetExpr (P_LO)) == &ERRSet || !NeedLex (L_RBRACE)) {	// {y}	Braces
					return &ERRSet;
				}
			}
			break;

		case L_ADD:				// +y	Self
			if (!UnaryOp (P_UNARY, &x, SelfNum)) {
				return &ERRSet;
			}
			break;

		case L_SUB:				// -y	Negation
			if (!UnaryOp (P_UNARY, &x, NegNum)) {
				return &ERRSet;
			}
			break;

		case L_MUL:				// .y	Star
			if (!UnaryOp (P_UNARY, &x, StarNum)) {
				return &ERRSet;
			}
			break;

		case L_AND:				// &y	Day
			if (!UnaryOp (P_UNARY, &x, DayNum)) {
				return &ERRSet;
			}
			break;

		case L_MAX:				// >>y	Positive absolute value
			if (!UnaryOp (P_UNARY, &x, AbsNum)) {
				return &ERRSet;
			}
			break;

		case L_MIN:				// <<y	Negative absolute value
			if (!UnaryOp (P_UNARY, &x, NAbsNum)) {
				return &ERRSet;
			}
			break;

		case L_LT:				// <y	Left Set
			if (!UnaryOp (P_UNARY, &x, SelfNum)) {
				return &ERRSet;
			}
			x = SetLeft (x);
			break;

		case L_GT:				// >y	Right Set
			if (!UnaryOp (P_UNARY, &x, SelfNum)) {
				return &ERRSet;
			}
			x = SetRight (x);
			break;

		case L_OR:				// !y	Not
			if (!UnaryOp (P_UNARY, &x, NotNum)) {
				return &ERRSet;
			}
			break;

		case L_SUMM:				// ??	Summary
			PrintVars (Variables);
			PrintStats ();
			return &ERRSet;

		case L_TERM:				// terminal
			{
				char		name[80];
				strcpy (name, lexname);
				switch (t = GetLex ()) {
				case L_ASG:
					if (AtEnd ()) {	// n=	Delete variable
						if ((n = GetPerm (name, TRUE)) == NULLNumber) {
							printf ("Undefined variable '%s'\n", name);
							return &ERRSet;
						}
					} else {	// n=y	Assign  variable
						if ((n = GetAtom (P_LO)) == NULLNumber) {
							return &ERRSet;
						}
						MakePerm (n, name);
					}
					break;
				case L_CASG:
					if (AtEnd ()) {	// n:=	Delete constant
						if ((n = GetPerm (name, TRUE)) == NULLNumber) {
							printf ("Undefined variable '%s'\n", name);
							return &ERRSet;
						}
					} else {	// n:=y	Assign constant
						if ((n = GetAtom (P_LO)) == NULLNumber) {
							return &ERRSet;
						}
						MakeConst (n, name);
					}
					break;
				default:		// n	Extract value
					UnLex (t);
					if ((n = GetPerm (name, FALSE)) == NULLNumber) {
						printf ("Undefined variable '%s'\n", name);
						return &ERRSet;
					}
					break;
				}
				x = &n->n_set;
			}
			break;

		case L_BAR:				// |y	Number with empty right set
			x = NULLSet;
			if (!BarOp (lexprio, &x)) {
				return &ERRSet;
			}
			break;

		case L_CMP:				// ::y	Show relative position
			if (!UnaryOp (P_UNARY, &x, SelfNum)) {
				return &ERRSet;
			}
			PrintRel (x, "", " < ", NumLT, 1);
			PrintRel (x, "", "", NumEQ, 0);
			PrintRel (x, " ? ", "", NumFUZ, 0);
			PrintRel (x, " < ", "", NumGT, -1);
			printf ("\n");
			return &ERRSet;

		default:
			printf ("Missing expression near %s\n", lexsymbols[t]);
			return &ERRSet;
		}

		if (x != NULLSet) {
			n = x->s_number;
			if (n->n_day < 0) {	// Non-numeric syntactic entity: re-parse
				UnLex (eToken (~n->n_day));
				continue;
			}
		}
		break;
	}


	while (x != &ERRSet) {
		switch (t = GetLex ()) {

		default:
			break;

		case L_MUL:				// x.y	Multiplication (Conway)
			if (p > P_MUL || !BinaryOp (ePrecedence (P_MUL+1), &x, MulNum)) {
				break;
			}
			continue;

		case L_NMUL:				// .. multiplication (Norton)
			if (p > P_MUL || !BinaryOp (ePrecedence (P_MUL+1), &x, NMulNum)) {
				break;
			}
			continue;

		case L_ADD:				// x+y	Addition
			if (p > P_ADD || !BinaryOp (ePrecedence (P_ADD+1), &x, AddNum)) {
				break;
			}
			continue;

		case L_SUB:				// x-y	Subtraction
			if (p > P_ADD || !BinaryOp (ePrecedence (P_ADD+1), &x, SubNum)) {
				break;
			}
			continue;

		case L_ORD:				// x:y	Ordinal sum
			if (p > P_ADD || !BinaryOp (ePrecedence (P_ADD+1), &x, OrdNum)) {
				break;
			}
			continue;

		case L_MAX:				// x>>y	Maximum
			if (p > P_MAX || !BinaryOp (ePrecedence (P_MAX+1), &x, MaxNum)) {
				break;
			}
			continue;

		case L_MIN:				// x<<y	Minimum
			if (p > P_MAX || !BinaryOp (ePrecedence (P_MAX+1), &x, MinNum)) {
				break;
			}
			continue;

		case L_AND:				// x&y	Fast join
			if (p > P_AND || !BinaryOp (ePrecedence (P_AND+1), &x, AndNum)) {
				break;
			}
			continue;

		case L_ALSO:				// x&&y	Slow join
			if (p > P_AND || !BinaryOp (ePrecedence (P_AND+1), &x, AlsoNum)) {
				break;
			}
			continue;

		case L_OR:				// ! tardy union
			if (p > P_OR || !BinaryOp (ePrecedence (P_OR+1), &x, OrNum)) {
				break;
			}
			continue;

		case L_UR:				// !! urgent union
			if (p > P_OR || !BinaryOp (ePrecedence (P_OR+1), &x, UrNum)) {
				break;
			}
			continue;

		case L_COMMA:				// x,y	Concatenation
			if (p > P_CAT || !CatOp (ePrecedence (P_CAT+1), &x)) {
				break;
			}
			continue;

		case L_BAR:				// x|y	Combination
			if (p > lexprio || !BarOp (lexprio, &x)) {
				break;
			}
			continue;

		case L_LE:				// x<=y	Less or equal?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumLE)) {
				break;
			}
			continue;

		case L_LF:				// x<?y	Less or fuzzy?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumLF)) {
				break;
			}
			continue;

		case L_LT:				// x<y	Less than?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumLT)) {
				break;
			}
			continue;

		case L_NL:				// x!<y	Not less than?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumNL)) {
				break;
			}
			continue;

		case L_GE:				// x>=y	Greater or equal?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumGE)) {
				break;
			}
			continue;

		case L_GF:				// x>?y	Greater or fuzzy?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumGF)) {
				break;
			}
			continue;

		case L_GT:				// x>y	Greater than?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumGT)) {
				break;
			}
			continue;

		case L_NG:				// !> not greater than?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumNG)) {
				break;
			}
			continue;

		case L_LG:				// <> less or greater?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumLG)) {
				break;
			}
			continue;

		case L_EQ:				// == equal?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumEQ)) {
				break;
			}
			continue;

		case L_NE:				// != not equal?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumNE)) {
				break;
			}
			continue;

		case L_FUZ:				// ? fuzzy or equal?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumFUZ)) {
				break;
			}
			continue;

		case L_NF:				// !? not fuzzy?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumNF)) {
				break;
			}
			continue;

		case L_EF:				// ?= equal or fuzzy?
			if (p > P_CMP || !RelOp (P_CMP, &x, NumEF)) {
				break;
			}
			continue;

		case L_CMP:				// :: compare
			if (p > P_CMP || !CmpOp (P_CMP, &x)) {
				break;
			}
			continue;

		case L_LPAREN:				// x(y)	Implicit concatenation
		case L_LBRACE:				// x{y}	Implicit concatenation
		case L_TERM:				// x y	Implicit concatenation
			if (p > P_VEC) {
				break;
			}
			UnLex (t);
			tpSet		y = GetExpr (P_HI);
			if (y == &ERRSet) {
				// ### LEAK: we should free x first!
				return y;
			}
			if (y != NULLSet) {
				n = y->s_number;
				if (n->n_day < 0) {	// Non-numeric syntactic entity: re-parse
					UnLex (eToken (~n->n_day));
					continue;
				}
				x = MixSets (x, y, 0);
			}
			continue;
		}

		break;
	}

	UnLex (t);

	if (x != NULLSet && x != &ERRSet) {
		n = x->s_number;
		if (n->n_day < 0) {	// Non-numeric syntactic entity?
			if (p != P_LO && p != P_HI) {
				printf ("Number expected near %s\n", lexsymbols[int (~n->n_day)]);
 				return &ERRSet;
			}
		}
	}

	return x;
}



// Get a statement

tBool GetStmt ()
{
	tpSet		s;		// typed-in set
	eToken		t;		// next token

	peekc = ' ';

	switch (t = GetLex ()) {
	default:
		UnLex (t);
		if ((s = GetExpr (P_LO)) == &ERRSet || !NeedLex (L_EOL)) {
			return FALSE;
		}
		if (fin != stdin) {	// don't echo prologue input
			break;
		}
		if (s == NULLSet) {
		} else if (s->s_next == NULLSet) {
			PrintNum (s->s_number, TRUE);
		} else {
			PrintSet (s);
		}
		printf ("\n");
		break;
	case L_EOL:
		break;
	}

	return TRUE;
}



// Startup message

char license [] = {
	"Numbers and Games calculator\n"
	"Copyright 1988, 1989, 1993, 1994, 1996, 2011, 2013 by Mark D. Niemiec\n"
	"This program comes with ABSOLUTELY NO WARRANTY.\n"
	"This is free software, licensed under the Gnu Public License, version 3.\n"
	"You are welcome to redistribute it under certain conditions.\n"
	"See license.txt for details.\n\n"
};



// Main entry point

int main (
	int		argc,		// number of command-line parameters
	tpString	argv)		// list of command-line parameters
{
	tcString	path;

	for (; argc > 1 && argv[1][0] == '-'; --argc, ++argv) {
		if (!strcmp (argv[1], "-v")) {
			verbose = TRUE;
		} else if (!strcmp (argv[1], "-q")) {
			quiet = TRUE;
		} else {
			break;
		}
	}

	switch (argc) {
	default:
		fprintf (stderr, "Usage: onagcalc [-q] [-v] [script.dat]\n");
		return 1;
	case 1:
		path = "onagcalc.dat";
		break;
	case 2:
		path = argv[1];
		break;
	}

	if ((fin = fopen (path, "r")) == NULLFILE) {
		fprintf (stderr, "Cannot open %s\n", path);
		return 1;
	}

	InitNum ();

	if (!quiet) {
		printf (license);
	}

	for (;;) {
		if (fin == stdin) {
			printf ("   ");
			fflush (stdout);
		}
		GetStmt ();
		while (peekc != '\n') {
			peekc = Getcf (EOF);
		}
		peekc = ' ';
		peekt = L_NULL;
		peekt2 = L_NULL;
		GarbageCollect ();
	}
}



// End onagcalc.cpp
